# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=_ZN17pa_scheduler_ccecL31pa_real_vector_add_workload_aivEPU3AS1fS1_S1_j
# binding=LOCAL
# final_pc=0x5dc00
# size=268
# instruction_count=66
# encoded_word_count=67
# body_sha256=d55e1e765b39016fa5139e91d947f6816b6bea5ff18a176c45b48d5ada5a5d8f
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction

0x000000000005dc00 (+0x00000000)  072207a0  MOV_XD_IMM                      X17, #1952
0x000000000005dc04 (+0x00000004)  03ffe868  ST_XD_XN_IMM.B64                X31, X30, #2152
0x000000000005dc08 (+0x00000008)  03fbe860  ST_XD_XN_IMM.B64                X29, X30, #2144
0x000000000005dc0c (+0x0000000c)  003be882  SUB.S64                         X29, X30, X17
0x000000000005dc10 (+0x00000010)  07220018  MOV_XD_IMM                      X17, #24
0x000000000005dc14 (+0x00000014)  003de882  SUB.S64                         X30, X30, X17
0x000000000005dc18 (+0x00000018)  028a3a00  ZEROEXT.U32                     X5, X3
0x000000000005dc1c (+0x0000001c)  07080000  MOV_XD_IMM                      X4, #0
0x000000000005dc20 (+0x00000020)  0000520e  CMP.S64.EQ                      X5, X4
0x000000000005dc24 (+0x00000024)  40200035  JUMPC                           #53
0x000000000005dc28 (+0x00000028)  07120000  MOV_XD_IMM                      X9, #0
0x000000000005dc2c (+0x0000002c)  0714007e  MOV_XD_IMM                      X10, #126
0x000000000005dc30 (+0x00000030)  07930100  MOVK                            X9, #256, #2
0x000000000005dc34 (+0x00000034)  0212ac1f  INSERT_XD_XN.S64                X9, X10, #0, #31
0x000000000005dc38 (+0x00000038)  07140000  MOV_XD_IMM                      X10, #0
0x000000000005dc3c (+0x0000003c)  07160002  MOV_XD_IMM                      X11, #2
0x000000000005dc40 (+0x00000040)  07550080  MOVK                            X10, #128, #1
0x000000000005dc44 (+0x00000044)  0214bc0f  INSERT_XD_XN.S64                X10, X11, #0, #15
0x000000000005dc48 (+0x00000048)  07100000  MOV_XD_IMM                      X8, #0
0x000000000005dc4c (+0x0000004c)  02d40220  SHL.B64                         X10, #32
0x000000000005dc50 (+0x00000050)  07160200  MOV_XD_IMM                      X11, #512
0x000000000005dc54 (+0x00000054)  070a0200  MOV_XD_IMM                      X5, #512
0x000000000005dc58 (+0x00000058)  070c0800  MOV_XD_IMM                      X6, #2048
0x000000000005dc5c (+0x0000005c)  070e0000  MOV_XD_IMM                      X7, #0
0x000000000005dc60 (+0x00000060)  07d10001  MOVK                            X8, #1, #3
0x000000000005dc64 (+0x00000064)  0214bc1f  INSERT_XD_XN.S64                X10, X11, #0, #31
0x000000000005dc68 (+0x00000068)  07160000  MOV_XD_IMM                      X11, #0
0x000000000005dc6c (+0x0000006c)  071a0001  MOV_XD_IMM                      X13, #1
0x000000000005dc70 (+0x00000070)  071c0004  MOV_XD_IMM                      X14, #4
0x000000000005dc74 (+0x00000074)  07cb0002  MOVK                            X5, #2, #3
0x000000000005dc78 (+0x00000078)  078d0004  MOVK                            X6, #4, #2
0x000000000005dc7c (+0x0000007c)  074f0001  MOVK                            X7, #1, #1
0x000000000005dc80 (+0x00000080)  02104c1f  INSERT_XD_XN.S64                X8, X4, #0, #31
0x000000000005dc84 (+0x00000084)  07570002  MOVK                            X11, #2, #1
0x000000000005dc88 (+0x00000088)  075b0020  MOVK                            X13, #32, #1
0x000000000005dc8c (+0x0000008c)  07dd0100  MOVK                            X14, #256, #3
0x000000000005dc90 (+0x00000090)  74880316  MOV_SRC_TO_DST_ALIGNv2.B32      X4, X0, X6, X5
0x000000000005dc94 (+0x00000094)  748e1316  MOV_SRC_TO_DST_ALIGNv2.B32      X7, X1, X6, X5
0x000000000005dc98 (+0x00000098)  40a01080  SET_FLAG                        MTE2
0x000000000005dc9c (+0x0000009c)  15e02000  WAIT_FLAG                       MTE2
0x000000000005dca0 (+0x000000a0)  4312a42c  PUSH_PB                         X9, X10, X8, X11
0x000000000005dca4 (+0x000000a4)  02180880  MOV_XD_SPR.S64                  X12, PC
0x000000000005dca8 (+0x000000a8)  071e9f57  MOV_XD_IMM                      X15, #40791
0x000000000005dcac (+0x000000ac)  41400000  NOP
0x000000000005dcb0 (+0x000000b0)  41400000  NOP
0x000000000005dcb4 (+0x000000b4)  02de0202  SHL.B64                         X15, #2
0x000000000005dcb8 (+0x000000b8)  001ef601  ADD.S64                         X15, X15, X12
0x000000000005dcbc (+0x000000bc)  15e00185154f0000  VF                              X15, #12
0x000000000005dcc4 (+0x000000c4)  15e0a800  SET_FLAG                        VEC
0x000000000005dcc8 (+0x000000c8)  40c00680  WAIT_FLAG                       VEC
0x000000000005dccc (+0x000000cc)  02e0d900  MOV_SPR_XN.B64                  LOOP_SIZE_UBTOOUT, X13
0x000000000005dcd0 (+0x000000d0)  02e2e900  MOV_SPR_XN.B64                  LOOP1_STRIDE_UBTOOUT, X14
0x000000000005dcd4 (+0x000000d4)  02e4e900  MOV_SPR_XN.B64                  LOOP2_STRIDE_UBTOOUT, X14
0x000000000005dcd8 (+0x000000d8)  74c4b314  MOV_SRC_TO_DST_ALIGNv2.B8       X2, X11, X6, X5
0x000000000005dcdc (+0x000000dc)  02e0d900  MOV_SPR_XN.B64                  LOOP_SIZE_UBTOOUT, X13
0x000000000005dce0 (+0x000000e0)  40a41403  SET_FLAG                        MTE3
0x000000000005dce4 (+0x000000e4)  40c41403  WAIT_FLAG                       MTE3
0x000000000005dce8 (+0x000000e8)  08863001  SUB_IMM.S64                     X3, X3, #1
0x000000000005dcec (+0x000000ec)  029e3a00  ZEROEXT.U32                     X15, X3
0x000000000005dcf0 (+0x000000f0)  0000f21e  CMP.S64.NE                      X15, X4
0x000000000005dcf4 (+0x000000f4)  4020ffe7  JUMPC                           #65511
0x000000000005dcf8 (+0x000000f8)  07220018  MOV_XD_IMM                      X17, #24
0x000000000005dcfc (+0x000000fc)  003de881  ADD.S64                         X30, X30, X17
0x000000000005dd00 (+0x00000100)  1cffe868  LD_XD_XN_IMM.B64                X31, X30, #2152
0x000000000005dd04 (+0x00000104)  1cfbe860  LD_XD_XN_IMM.B64                X29, X30, #2144
0x000000000005dd08 (+0x00000108)  4061f000  RET
