# schema=pa_final_linked_disassembly/v1
# variant=compete-first
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=82a27e206ee1b2411964c0530c73adf92a2b032ac202a7c65c6b5f7d76a4571b
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=8fd6209b2f0f9d1fb48d4d8a16cf27649e26071153b908e1e0e39ca107d63589
# symbol=_ZN17pa_scheduler_ccecL25pa_real_cube_workload_aicEPU3AS1fS1_S1_j
# binding=LOCAL
# final_pc=0x70
# size=192
# instruction_count=48
# encoded_word_count=48
# body_sha256=b8afa7640101b76f5e91a2e172ddd1cb39b6e11ccecd0c4395057eabc1e2bc00
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:48
#
# [DWARF] ccec/ccec_ops.h:72
#      66 | #if defined(PA_CCEC_OPS_DEFINE_REAL_WORKLOAD) && defined(PA_BUILD_AIC)
#      67 | // QK/PV 的首版真实负载使用完整的 128x128 float cube 路径。输入来自独立 GM
#      68 | // workspace，输出属于当前 worker；每次迭代都等 FIX 写回 GM 后再复用 L0C，
#      69 | // 因而函数返回就是该模拟 task 的完成边界，而不是单纯的指令发射边界。
#      70 | static __aicore__ __attribute__((noinline, used)) void pa_real_cube_workload_aic(
#      71 |     __gm__ float *input_a, __gm__ float *input_b, __gm__ float *output, uint32_t repeats
# >    72 | ) {
0x0000000000000070 (+0x00000000)  028a3a00  ZEROEXT.U32                     X5, X3
0x0000000000000074 (+0x00000004)  07080000  MOV_XD_IMM                      X4, #0
# [DWARF] ccec/ccec_ops.h:105
#      99 |     TASSIGN(input_a_mat, 0x0);
#     100 |     TASSIGN(input_b_mat, 0x20000);
#     101 |     TASSIGN(input_a_l0, 0x0);
#     102 |     TASSIGN(input_b_l0, 0x0);
#     103 |     TASSIGN(output_l0, 0x0);
#     104 | 
# >   105 |     for (uint32_t iteration = 0; iteration < repeats; ++iteration) {
0x0000000000000078 (+0x00000008)  0000520e  CMP.S64.EQ                      X5, X4
0x000000000000007c (+0x0000000c)  4020002c  JUMPC                           #44
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x0000000000000080 (+0x00000010)  070a0001  MOV_XD_IMM                      X5, #1
0x0000000000000084 (+0x00000014)  07160080  MOV_XD_IMM                      X11, #128
0x0000000000000088 (+0x00000018)  071c0800  MOV_XD_IMM                      X14, #2048
0x000000000000008c (+0x0000001c)  074b0001  MOVK                            X5, #1, #1
0x0000000000000090 (+0x00000020)  070e2000  MOV_XD_IMM                      X7, #8192
0x0000000000000094 (+0x00000024)  07100000  MOV_XD_IMM                      X8, #0
0x0000000000000098 (+0x00000028)  07120008  MOV_XD_IMM                      X9, #8
0x000000000000009c (+0x0000002c)  07140000  MOV_XD_IMM                      X10, #0
0x00000000000000a0 (+0x00000030)  07578008  MOVK                            X11, #32776, #1
0x00000000000000a4 (+0x00000034)  07180001  MOV_XD_IMM                      X12, #1
0x00000000000000a8 (+0x00000038)  071a0080  MOV_XD_IMM                      X13, #128
0x00000000000000ac (+0x0000003c)  075d0080  MOVK                            X14, #128, #1
0x00000000000000b0 (+0x00000040)  078b0080  MOVK                            X5, #128, #2
0x00000000000000b4 (+0x00000044)  070c0080  MOV_XD_IMM                      X6, #128
0x00000000000000b8 (+0x00000048)  07cf0080  MOVK                            X7, #128, #3
0x00000000000000bc (+0x0000004c)  07510002  MOVK                            X8, #2, #1
0x00000000000000c0 (+0x00000050)  07530008  MOVK                            X9, #8, #1
0x00000000000000c4 (+0x00000054)  07951008  MOVK                            X10, #4104, #2
0x00000000000000c8 (+0x00000058)  07d7a000  MOVK                            X11, #40960, #3
0x00000000000000cc (+0x0000005c)  07994000  MOVK                            X12, #16384, #2
0x00000000000000d0 (+0x00000060)  079b0800  MOVK                            X13, #2048, #2
0x00000000000000d4 (+0x00000064)  079d0080  MOVK                            X14, #128, #2
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tload_common.hpp:256
#     250 |     uint16_t loop3DstStride = TileData::Rows;                          // unit is 32B
#     251 |     uint16_t loop4DstStride = 0;                                       // because ndNum = 1
#     252 |     uint64_t mte2NzPara = static_cast<uint64_t>(loop4DstStride) << 48; // MTE2_NZ_PARA[63:48]
#     253 |     mte2NzPara |= static_cast<uint64_t>(loop3DstStride) << 32;         // MTE2_NZ_PARA[47:32]
#     254 |     mte2NzPara |= static_cast<uint64_t>(loop2DstStride) << 16;         // MTE2_NZ_PARA[31:16]
#     255 |     mte2NzPara |= static_cast<uint64_t>(ndNum);                        // MTE2_NZ_PARA[15:0]
# >   256 |     set_mte2_nz_para(mte2NzPara);                                      // only set once
0x00000000000000d8 (+0x00000068)  02fe5900  MOV_SPR_XN.B64                  MTE2_NZ_PARA, X5
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch_cce_intrinsic.hpp:156
#     150 |                                                   uint8_t l2CacheCtl, uint16_t nValue, uint32_t dValue,
#     151 |                                                   uint64_t loop4SrcStride, bool smallc0En = false)
#     152 | {
#     153 |     using U = std::conditional_t<sizeof(T) == sizeof(uint8_t), uint8_t,
#     154 |                                  std::conditional_t<sizeof(T) == sizeof(uint16_t), uint16_t, uint32_t>>;
#     155 | #if defined(PTO_NPU_ARCH_A5)
# >   156 |     copy_gm_to_cbuf_multi_nd2nz(reinterpret_cast<__cbuf__ U *>(dst), reinterpret_cast<__gm__ U *>(src), sid,
0x00000000000000dc (+0x0000006c)  6b08039a  MOV_OUT_TO_L1_MULTI_ND2NZ.B32S  X4, X0, X7, X6
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tload_common.hpp:256
#     250 |     uint16_t loop3DstStride = TileData::Rows;                          // unit is 32B
#     251 |     uint16_t loop4DstStride = 0;                                       // because ndNum = 1
#     252 |     uint64_t mte2NzPara = static_cast<uint64_t>(loop4DstStride) << 48; // MTE2_NZ_PARA[63:48]
#     253 |     mte2NzPara |= static_cast<uint64_t>(loop3DstStride) << 32;         // MTE2_NZ_PARA[47:32]
#     254 |     mte2NzPara |= static_cast<uint64_t>(loop2DstStride) << 16;         // MTE2_NZ_PARA[31:16]
#     255 |     mte2NzPara |= static_cast<uint64_t>(ndNum);                        // MTE2_NZ_PARA[15:0]
# >   256 |     set_mte2_nz_para(mte2NzPara);                                      // only set once
0x00000000000000e0 (+0x00000070)  02fe5900  MOV_SPR_XN.B64                  MTE2_NZ_PARA, X5
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch_cce_intrinsic.hpp:156
#     150 |                                                   uint8_t l2CacheCtl, uint16_t nValue, uint32_t dValue,
#     151 |                                                   uint64_t loop4SrcStride, bool smallc0En = false)
#     152 | {
#     153 |     using U = std::conditional_t<sizeof(T) == sizeof(uint8_t), uint8_t,
#     154 |                                  std::conditional_t<sizeof(T) == sizeof(uint16_t), uint16_t, uint32_t>>;
#     155 | #if defined(PTO_NPU_ARCH_A5)
# >   156 |     copy_gm_to_cbuf_multi_nd2nz(reinterpret_cast<__cbuf__ U *>(dst), reinterpret_cast<__gm__ U *>(src), sid,
0x00000000000000e4 (+0x00000074)  6b10139a  MOV_OUT_TO_L1_MULTI_ND2NZ.B32S  X8, X1, X7, X6
# [DWARF] ccec/ccec_ops.h:108
#     102 |     TASSIGN(input_b_l0, 0x0);
#     103 |     TASSIGN(output_l0, 0x0);
#     104 | 
#     105 |     for (uint32_t iteration = 0; iteration < repeats; ++iteration) {
#     106 |         TLOAD(input_a_mat, input_a_global);
#     107 |         TLOAD(input_b_mat, input_b_global);
# >   108 |         set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
0x00000000000000e8 (+0x00000078)  40a01180  SET_FLAG                        MTE2
# [DWARF] ccec/ccec_ops.h:109
# >   109 |         wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
0x00000000000000ec (+0x0000007c)  40c01180  WAIT_FLAG                       MTE2
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TExtract.hpp:135
#     129 |         constexpr uint16_t dstStride = dstRow >> SHIFT_BLOCK_LEN;
#     130 | 
#     131 |         if constexpr (isFp4Type) {
#     132 |             load_cbuf_to_ca_s4(dstAddr, srcAddr, mStartPosition, kStartPosition / KHALF, mStep, kStep / KHALF,
#     133 |                                srcStride, dstStride, 0);
#     134 |         } else {
# >   135 |             load_cbuf_to_ca(dstAddr, srcAddr, mStartPosition, kStartPosition, mStep, kStep, srcStride, dstStride, 0);
0x00000000000000f0 (+0x00000080)  6cc84524  LOAD_2Dv2.B32                   X4, X4, X10, X9
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch_cce_intrinsic.hpp:45
#      39 | }
#      40 | #elif defined(PTO_NPU_ARCH_A5) || defined(PTO_NPU_ARCH_KIRIN9030)
#      41 | template <bool Transpose, typename T>
#      42 | PTO_INTERNAL void pto_load_cbuf_to_cb(__cb__ T *dst, __cbuf__ T *src, uint16_t mStartPosition, uint16_t kStartPosition,
#      43 |                                       uint8_t mStep, uint8_t kStep, uint16_t srcStride, uint16_t dstStride)
#      44 | {
# >    45 |     load_cbuf_to_cb(dst, src, mStartPosition, kStartPosition, mStep, kStep, srcStride, dstStride, Transpose);
0x00000000000000f4 (+0x00000084)  6cc88527  LOAD_2Dv2.B32                   X4, X8, X10, X9
# [DWARF] ccec/ccec_ops.h:112
#     106 |         TLOAD(input_a_mat, input_a_global);
#     107 |         TLOAD(input_b_mat, input_b_global);
#     108 |         set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
#     109 |         wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
#     110 |         TMOV(input_a_l0, input_a_mat);
#     111 |         TMOV(input_b_l0, input_b_mat);
# >   112 |         set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
0x00000000000000f8 (+0x00000088)  40a00d00  SET_FLAG                        MTE1
# [DWARF] ccec/ccec_ops.h:113
# >   113 |         wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
0x00000000000000fc (+0x0000008c)  40c00d00  WAIT_FLAG                       MTE1
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TMatmul.hpp:38
#      32 | {
#      33 |     // when gemv = 1 , GEMV mode is disable.
#      34 |     __cc__ typename TileRes::DType *c = (__cc__ typename TileRes::DType *)__cce_get_tile_ptr(cMatrix);
#      35 |     __ca__ typename TileLeft::DType *a = (__ca__ typename TileLeft::DType *)__cce_get_tile_ptr(aMatrix);
#      36 |     __cb__ typename TileRight::DType *b = (__cb__ typename TileRight::DType *)__cce_get_tile_ptr(bMatrix);
#      37 | 
# >    38 |     mad(c, a, b, m, k, n, static_cast<uint8_t>(Phase), gemvCtrl, cmatrixSource, cmatrixInitVal);
0x0000000000000100 (+0x00000090)  f088422d  MMAD                            X4, X4, X4, X11
# [DWARF] ccec/ccec_ops.h:115
#     109 |         wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
#     110 |         TMOV(input_a_l0, input_a_mat);
#     111 |         TMOV(input_b_l0, input_b_mat);
#     112 |         set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
#     113 |         wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
#     114 |         TMATMUL(output_l0, input_a_l0, input_b_l0);
# >   115 |         set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
0x0000000000000104 (+0x00000094)  40a04900  SET_FLAG                        CUBE
# [DWARF] ccec/ccec_ops.h:116
# >   116 |         wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
0x0000000000000108 (+0x00000098)  40c04900  WAIT_FLAG                       CUBE
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tstore_common.hpp:52
#      46 |                      ((static_cast<uint64_t>(reluPreMode) & 0x7) << 39) | //  Xt[41:39] relu pre mode
#      47 |                      (static_cast<uint64_t>(nz2ndEn & 0x1) << 43);        //  Xt[43] nz2nd control bit
#      48 |     uint64_t config =
#      49 |         ndNum |                                               // ND_PARA[15:0] the number of source nd
#      50 |         (static_cast<uint64_t>(srcNdStride & 0xffff) << 16) | // ND_PARA[31:16] the stride of source nd
#      51 |         (static_cast<uint64_t>(dstNdStride & 0xffff) << 32);  // ND_PARA[47:32] the stride of destination nd
# >    52 |     set_loop3_para(config);
0x000000000000010c (+0x0000009c)  02c2c900  MOV_SPR_XN.B64                  LOOP3_PARA, X12
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tstore_common.hpp:53
# >    53 |     copy_matrix_cc_to_gm(dstGlobalAddr, srcTileAddr, xmReg, xtReg);
0x0000000000000110 (+0x000000a0)  c2044734  FIX_L0C_TO_DST
# [DWARF] ccec/ccec_ops.h:118
#     112 |         set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
#     113 |         wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
#     114 |         TMATMUL(output_l0, input_a_l0, input_b_l0);
#     115 |         set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
#     116 |         wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
#     117 |         TSTORE(output_global, output_l0);
# >   118 |         set_flag(PIPE_FIX, PIPE_S, EVENT_ID7);
0x0000000000000114 (+0x000000a4)  40a42803  SET_FLAG                        FIXP
# [DWARF] ccec/ccec_ops.h:119
# >   119 |         wait_flag(PIPE_FIX, PIPE_S, EVENT_ID7);
0x0000000000000118 (+0x000000a8)  40c42803  WAIT_FLAG                       FIXP
# [DWARF] ccec/ccec_ops.h:105
#      99 |     TASSIGN(input_a_mat, 0x0);
#     100 |     TASSIGN(input_b_mat, 0x20000);
#     101 |     TASSIGN(input_a_l0, 0x0);
#     102 |     TASSIGN(input_b_l0, 0x0);
#     103 |     TASSIGN(output_l0, 0x0);
#     104 | 
# >   105 |     for (uint32_t iteration = 0; iteration < repeats; ++iteration) {
0x000000000000011c (+0x000000ac)  08863001  SUB_IMM.S64                     X3, X3, #1
0x0000000000000120 (+0x000000b0)  029e3a00  ZEROEXT.U32                     X15, X3
0x0000000000000124 (+0x000000b4)  0000f21e  CMP.S64.NE                      X15, X4
0x0000000000000128 (+0x000000b8)  4020ffec  JUMPC                           #65516
# [DWARF] ccec/ccec_ops.h:121
#     115 |         set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
#     116 |         wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
#     117 |         TSTORE(output_global, output_l0);
#     118 |         set_flag(PIPE_FIX, PIPE_S, EVENT_ID7);
#     119 |         wait_flag(PIPE_FIX, PIPE_S, EVENT_ID7);
#     120 |     }
# >   121 | }
0x000000000000012c (+0x000000bc)  4061f000  RET
