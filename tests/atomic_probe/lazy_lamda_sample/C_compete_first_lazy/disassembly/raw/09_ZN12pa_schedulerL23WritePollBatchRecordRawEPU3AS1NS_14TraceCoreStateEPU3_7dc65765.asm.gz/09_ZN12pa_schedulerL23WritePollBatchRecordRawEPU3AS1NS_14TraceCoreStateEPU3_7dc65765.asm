# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=_ZN12pa_schedulerL23WritePollBatchRecordRawEPU3AS1NS_14TraceCoreStateEPU3AS1NS_11TraceRecordEjmmjj
# binding=LOCAL
# final_pc=0x5db20
# size=220
# instruction_count=55
# encoded_word_count=55
# body_sha256=1fd702642d07bfb00a40e2f710068a59fc171927a070d63778975d757fe07add
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction

0x000000000005db20 (+0x00000000)  070e0000  MOV_XD_IMM                      X7, #0
0x000000000005db24 (+0x00000004)  0000038e  CMP.S64.EQ                      X0, X7
0x000000000005db28 (+0x00000008)  4020002d  JUMPC                           #45
0x000000000005db2c (+0x0000000c)  07100000  MOV_XD_IMM                      X8, #0
0x000000000005db30 (+0x00000010)  0000140e  CMP.S64.EQ                      X1, X8
0x000000000005db34 (+0x00000014)  4020002a  JUMPC                           #42
0x000000000005db38 (+0x00000018)  02922a00  ZEROEXT.U32                     X9, X2
0x000000000005db3c (+0x0000001c)  0000940e  CMP.S64.EQ                      X9, X8
0x000000000005db40 (+0x00000020)  40200027  JUMPC                           #39
0x000000000005db44 (+0x00000024)  1c840000  LD_XD_XN_IMM.B32                X2, X0, #0
0x000000000005db48 (+0x00000028)  004024ae  CMP.U64.LT                      X2, X9
0x000000000005db4c (+0x0000002c)  40200002  JUMPC                           #2
0x000000000005db50 (+0x00000030)  40000025  JUMP                            #37
0x000000000005db54 (+0x00000034)  020e2800  MOV_XD_XN.S64                   X7, X2
0x000000000005db58 (+0x00000038)  02ce0206  SHL.B64                         X7, #6
0x000000000005db5c (+0x0000003c)  00021381  ADD.S64                         X1, X1, X7
0x000000000005db60 (+0x00000040)  09c61201  STP_XI_XJ_XN.B64                X3, X4, X1, #0
0x000000000005db64 (+0x00000044)  07060001  MOV_XD_IMM                      X3, #1
0x000000000005db68 (+0x00000048)  02063080  NEG.S64                         X3, X3
0x000000000005db6c (+0x0000004c)  03c61010  ST_XD_XN_IMM.B64                X3, X1, #16
0x000000000005db70 (+0x00000050)  0706000e  MOV_XD_IMM                      X3, #14
0x000000000005db74 (+0x00000054)  03861018  ST_XD_XN_IMM.B32                X3, X1, #24
0x000000000005db78 (+0x00000058)  070e000d  MOV_XD_IMM                      X7, #13
0x000000000005db7c (+0x0000005c)  1c86001c  LD_XD_XN_IMM.B32                X3, X0, #28
0x000000000005db80 (+0x00000060)  0386101c  ST_XD_XN_IMM.B32                X3, X1, #28
0x000000000005db84 (+0x00000064)  1c860018  LD_XD_XN_IMM.B32                X3, X0, #24
0x000000000005db88 (+0x00000068)  03861020  ST_XD_XN_IMM.B32                X3, X1, #32
0x000000000005db8c (+0x0000006c)  02866a00  ZEROEXT.U32                     X3, X6
0x000000000005db90 (+0x00000070)  1c880014  LD_XD_XN_IMM.B32                X4, X0, #20
0x000000000005db94 (+0x00000074)  004033be  CMP.U64.GT                      X3, X7
0x000000000005db98 (+0x00000078)  03881024  ST_XD_XN_IMM.B32                X4, X1, #36
0x000000000005db9c (+0x0000007c)  07080090  MOV_XD_IMM                      X4, #144
0x000000000005dba0 (+0x00000080)  40200008  JUMPC                           #8
0x000000000005dba4 (+0x00000084)  0708818c  MOV_XD_IMM                      X4, #33164
0x000000000005dba8 (+0x00000088)  07490002  MOVK                            X4, #2, #1
0x000000000005dbac (+0x0000008c)  07890000  MOVK                            X4, #0, #2
0x000000000005dbb0 (+0x00000090)  07c90000  MOVK                            X4, #0, #3
0x000000000005dbb4 (+0x00000094)  020e0880  MOV_XD_SPR.S64                  X7, PC
0x000000000005dbb8 (+0x00000098)  00084381  ADD.S64                         X4, X4, X7
0x000000000005dbbc (+0x0000009c)  01884180  LD_XD_XN.B32                    X4, X4, X3
0x000000000005dbc0 (+0x000000a0)  02ca0208  SHL.B64                         X5, #8
0x000000000005dbc4 (+0x000000a4)  00c6428b  OR.B64                          X3, X4, X5
0x000000000005dbc8 (+0x000000a8)  08021028  ADD_IMM.S64                     X1, X1, #40
0x000000000005dbcc (+0x000000ac)  09861301  STP_XI_XJ_XN.B32                X3, X6, X1, #0
0x000000000005dbd0 (+0x000000b0)  08022001  ADD_IMM.S64                     X1, X2, #1
0x000000000005dbd4 (+0x000000b4)  070e0001  MOV_XD_IMM                      X7, #1
0x000000000005dbd8 (+0x000000b8)  03820000  ST_XD_XN_IMM.B32                X1, X0, #0
0x000000000005dbdc (+0x000000bc)  02007800  MOV_XD_XN.S64                   X0, X7
0x000000000005dbe0 (+0x000000c0)  4061f000  RET
0x000000000005dbe4 (+0x000000c4)  1c820004  LD_XD_XN_IMM.B32                X1, X0, #4
0x000000000005dbe8 (+0x000000c8)  070e0000  MOV_XD_IMM                      X7, #0
0x000000000005dbec (+0x000000cc)  08021001  ADD_IMM.S64                     X1, X1, #1
0x000000000005dbf0 (+0x000000d0)  03820004  ST_XD_XN_IMM.B32                X1, X0, #4
0x000000000005dbf4 (+0x000000d4)  02007800  MOV_XD_XN.S64                   X0, X7
0x000000000005dbf8 (+0x000000d8)  4061f000  RET
