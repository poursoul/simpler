# schema=pa_final_linked_disassembly/v1
# variant=compete-first
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=82a27e206ee1b2411964c0530c73adf92a2b032ac202a7c65c6b5f7d76a4571b
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=8fd6209b2f0f9d1fb48d4d8a16cf27649e26071153b908e1e0e39ca107d63589
# symbol=_ZN17pa_scheduler_ccecL31pa_real_vector_mul_workload_aivEPU3AS1fS1_S1_j
# binding=LOCAL
# final_pc=0x5dd0c
# size=268
# instruction_count=66
# encoded_word_count=67
# body_sha256=8bb7a51e530f1c2f2c336a661b18e890bdce87740c931135a953e81e046ef3eb
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:66
#
# [DWARF] ccec/ccec_ops.h:170
#     164 | ) {
#     165 |     RunRealVectorWorkload<false>(input_a, input_b, output, repeats);
#     166 | }
#     167 | 
#     168 | static __aicore__ __attribute__((noinline, used)) void pa_real_vector_mul_workload_aiv(
#     169 |     __gm__ float *input_a, __gm__ float *input_b, __gm__ float *output, uint32_t repeats
# >   170 | ) {
0x000000000005dd0c (+0x00000000)  072207a0  MOV_XD_IMM                      X17, #1952
0x000000000005dd10 (+0x00000004)  03ffe868  ST_XD_XN_IMM.B64                X31, X30, #2152
0x000000000005dd14 (+0x00000008)  03fbe860  ST_XD_XN_IMM.B64                X29, X30, #2144
0x000000000005dd18 (+0x0000000c)  003be882  SUB.S64                         X29, X30, X17
0x000000000005dd1c (+0x00000010)  07220018  MOV_XD_IMM                      X17, #24
0x000000000005dd20 (+0x00000014)  003de882  SUB.S64                         X30, X30, X17
0x000000000005dd24 (+0x00000018)  028a3a00  ZEROEXT.U32                     X5, X3
0x000000000005dd28 (+0x0000001c)  07080000  MOV_XD_IMM                      X4, #0
# [DWARF] ccec/ccec_ops.h:144
#     138 |     TileData input_b_tile(kRows, kCols);
#     139 |     TileData output_tile(kRows, kCols);
#     140 |     TASSIGN(input_a_tile, 0x0);
#     141 |     TASSIGN(input_b_tile, 0x10000);
#     142 |     TASSIGN(output_tile, 0x20000);
#     143 | 
# >   144 |     for (uint32_t iteration = 0; iteration < repeats; ++iteration) {
0x000000000005dd2c (+0x00000020)  0000520e  CMP.S64.EQ                      X5, X4
0x000000000005dd30 (+0x00000024)  40200035  JUMPC                           #53
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005dd34 (+0x00000028)  07120000  MOV_XD_IMM                      X9, #0
0x000000000005dd38 (+0x0000002c)  0714007e  MOV_XD_IMM                      X10, #126
0x000000000005dd3c (+0x00000030)  07930100  MOVK                            X9, #256, #2
0x000000000005dd40 (+0x00000034)  0212ac1f  INSERT_XD_XN.S64                X9, X10, #0, #31
0x000000000005dd44 (+0x00000038)  07140000  MOV_XD_IMM                      X10, #0
0x000000000005dd48 (+0x0000003c)  07160002  MOV_XD_IMM                      X11, #2
0x000000000005dd4c (+0x00000040)  07550080  MOVK                            X10, #128, #1
0x000000000005dd50 (+0x00000044)  0214bc0f  INSERT_XD_XN.S64                X10, X11, #0, #15
0x000000000005dd54 (+0x00000048)  07100000  MOV_XD_IMM                      X8, #0
0x000000000005dd58 (+0x0000004c)  02d40220  SHL.B64                         X10, #32
0x000000000005dd5c (+0x00000050)  07160200  MOV_XD_IMM                      X11, #512
0x000000000005dd60 (+0x00000054)  070a0200  MOV_XD_IMM                      X5, #512
0x000000000005dd64 (+0x00000058)  070c0800  MOV_XD_IMM                      X6, #2048
0x000000000005dd68 (+0x0000005c)  070e0000  MOV_XD_IMM                      X7, #0
0x000000000005dd6c (+0x00000060)  07d10001  MOVK                            X8, #1, #3
0x000000000005dd70 (+0x00000064)  0214bc1f  INSERT_XD_XN.S64                X10, X11, #0, #31
0x000000000005dd74 (+0x00000068)  07160000  MOV_XD_IMM                      X11, #0
0x000000000005dd78 (+0x0000006c)  071a0001  MOV_XD_IMM                      X13, #1
0x000000000005dd7c (+0x00000070)  071c0004  MOV_XD_IMM                      X14, #4
0x000000000005dd80 (+0x00000074)  07cb0002  MOVK                            X5, #2, #3
0x000000000005dd84 (+0x00000078)  078d0004  MOVK                            X6, #4, #2
0x000000000005dd88 (+0x0000007c)  074f0001  MOVK                            X7, #1, #1
0x000000000005dd8c (+0x00000080)  02104c1f  INSERT_XD_XN.S64                X8, X4, #0, #31
0x000000000005dd90 (+0x00000084)  07570002  MOVK                            X11, #2, #1
0x000000000005dd94 (+0x00000088)  075b0020  MOVK                            X13, #32, #1
0x000000000005dd98 (+0x0000008c)  07dd0100  MOVK                            X14, #256, #3
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch_cce_intrinsic.hpp:122
#     116 | PTO_INTERNAL void pto_copy_gm_to_ubuf_align_v2(__ubuf__ T *dst, __gm__ T *src, uint8_t sid, uint32_t nBurst,
#     117 |                                                uint32_t lenBurst, uint8_t leftPaddingCount, uint8_t rightPaddingCount,
#     118 |                                                bool constantPaddingCtl, uint8_t l2CacheCtl, uint64_t burstSrcStride,
#     119 |                                                uint32_t burstDstStride)
#     120 | {
#     121 | #if defined(PTO_NPU_ARCH_A5)
# >   122 |     copy_gm_to_ubuf_align_v2(dst, src, sid, nBurst, lenBurst, leftPaddingCount, rightPaddingCount, constantPaddingCtl,
0x000000000005dd9c (+0x00000090)  74880316  MOV_SRC_TO_DST_ALIGNv2.B32      X4, X0, X6, X5
0x000000000005dda0 (+0x00000094)  748e1316  MOV_SRC_TO_DST_ALIGNv2.B32      X7, X1, X6, X5
# [DWARF] ccec/ccec_ops.h:147
#     141 |     TASSIGN(input_b_tile, 0x10000);
#     142 |     TASSIGN(output_tile, 0x20000);
#     143 | 
#     144 |     for (uint32_t iteration = 0; iteration < repeats; ++iteration) {
#     145 |         TLOAD(input_a_tile, input_a_global);
#     146 |         TLOAD(input_b_tile, input_b_global);
# >   147 |         set_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
0x000000000005dda4 (+0x00000098)  40a01080  SET_FLAG                        MTE2
# [DWARF] ccec/ccec_ops.h:148
# >   148 |         wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
0x000000000005dda8 (+0x0000009c)  15e02000  WAIT_FLAG                       MTE2
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TBinOp.hpp:0
# [SOURCE unavailable]
0x000000000005ddac (+0x000000a0)  4312a42c  PUSH_PB                         X9, X10, X8, X11
0x000000000005ddb0 (+0x000000a4)  02180880  MOV_XD_SPR.S64                  X12, PC
0x000000000005ddb4 (+0x000000a8)  071e9f54  MOV_XD_IMM                      X15, #40788
0x000000000005ddb8 (+0x000000ac)  41400000  NOP
0x000000000005ddbc (+0x000000b0)  41400000  NOP
0x000000000005ddc0 (+0x000000b4)  02de0202  SHL.B64                         X15, #2
0x000000000005ddc4 (+0x000000b8)  001ef601  ADD.S64                         X15, X15, X12
0x000000000005ddc8 (+0x000000bc)  15e00185154f0000  VF                              X15, #12
# [DWARF] ccec/ccec_ops.h:154
#     148 |         wait_flag(PIPE_MTE2, PIPE_V, EVENT_ID0);
#     149 |         if constexpr (Multiply) {
#     150 |             TMUL(output_tile, input_a_tile, input_b_tile);
#     151 |         } else {
#     152 |             TADD(output_tile, input_a_tile, input_b_tile);
#     153 |         }
# >   154 |         set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
0x000000000005ddd0 (+0x000000c4)  15e0a800  SET_FLAG                        VEC
# [DWARF] ccec/ccec_ops.h:155
# >   155 |         wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
0x000000000005ddd4 (+0x000000c8)  40c00680  WAIT_FLAG                       VEC
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tstore_common.hpp:296
#     290 | 
#     291 |     uint64_t loopSizeConfig = 0;
#     292 |     uint64_t loop1Size = gShape2 & 0x1FFFFF;
#     293 |     loopSizeConfig |= loop1Size;
#     294 |     uint64_t loop2Size = (static_cast<uint64_t>(gShape1) & 0x3FFFFF) << 21;
#     295 |     loopSizeConfig |= loop2Size;
# >   296 |     set_loop_size_ubtoout(loopSizeConfig);
0x000000000005ddd8 (+0x000000cc)  02e0d900  MOV_SPR_XN.B64                  LOOP_SIZE_UBTOOUT, X13
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tstore_common.hpp:301
#     297 | 
#     298 |     uint64_t loop1Config = 0;
#     299 |     loop1Config |= ((uint64_t)loop1SrcStride) << 40;
#     300 |     loop1Config |= (uint64_t)loop1DstStride;
# >   301 |     set_loop1_stride_ubtoout(loop1Config);
0x000000000005dddc (+0x000000d0)  02e2e900  MOV_SPR_XN.B64                  LOOP1_STRIDE_UBTOOUT, X14
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tstore_common.hpp:305
#     302 |     uint64_t loop2Config = 0;
#     303 |     loop2Config |= ((uint64_t)loop2SrcStride) << 40;
#     304 |     loop2Config |= (uint64_t)loop2DstStride;
# >   305 |     set_loop2_stride_ubtoout(loop2Config);
0x000000000005dde0 (+0x000000d4)  02e4e900  MOV_SPR_XN.B64                  LOOP2_STRIDE_UBTOOUT, X14
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch_cce_intrinsic.hpp:255
#     249 | template <typename T>
#     250 | PTO_INTERNAL void pto_copy_ubuf_to_gm_align_v2(__gm__ T *dst, __ubuf__ T *src, uint8_t sid, uint32_t nBurst,
#     251 |                                                uint32_t lenBurst, uint8_t l2CacheCtl, uint64_t burstDstStride,
#     252 |                                                uint32_t burstSrcStride)
#     253 | {
#     254 | #if defined(PTO_NPU_ARCH_A5)
# >   255 |     copy_ubuf_to_gm_align_v2(dst, src, sid, nBurst, lenBurst, l2CacheCtl, burstDstStride, burstSrcStride);
0x000000000005dde4 (+0x000000d8)  74c4b314  MOV_SRC_TO_DST_ALIGNv2.B8       X2, X11, X6, X5
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/common/arch/register/tstore_common.hpp:321
#     315 |     uint32_t burstSrcStride = GetByteSize<typename TileData::DType>(TileData::Cols);
#     316 |     for (uint32_t k = 0; k < gShape0; k++) {
#     317 |         dstGlobalAddr = dstAddr + k * gStride0;
#     318 |         srcTileAddr = srcAddr + k * srcStride0;
#     319 |         TStoreInstr<TileData, GlobalData>(dstGlobalAddr, srcTileAddr, nBurst, lenBurst, burstDstStride, burstSrcStride);
#     320 |     }
# >   321 |     set_loop_size_ubtoout(1 << 21 | 1); // resume to normal mode
0x000000000005dde8 (+0x000000dc)  02e0d900  MOV_SPR_XN.B64                  LOOP_SIZE_UBTOOUT, X13
# [DWARF] ccec/ccec_ops.h:157
#     151 |         } else {
#     152 |             TADD(output_tile, input_a_tile, input_b_tile);
#     153 |         }
#     154 |         set_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
#     155 |         wait_flag(PIPE_V, PIPE_MTE3, EVENT_ID0);
#     156 |         TSTORE(output_global, output_tile);
# >   157 |         set_flag(PIPE_MTE3, PIPE_S, EVENT_ID7);
0x000000000005ddec (+0x000000e0)  40a41403  SET_FLAG                        MTE3
# [DWARF] ccec/ccec_ops.h:158
# >   158 |         wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID7);
0x000000000005ddf0 (+0x000000e4)  40c41403  WAIT_FLAG                       MTE3
# [DWARF] ccec/ccec_ops.h:144
#     138 |     TileData input_b_tile(kRows, kCols);
#     139 |     TileData output_tile(kRows, kCols);
#     140 |     TASSIGN(input_a_tile, 0x0);
#     141 |     TASSIGN(input_b_tile, 0x10000);
#     142 |     TASSIGN(output_tile, 0x20000);
#     143 | 
# >   144 |     for (uint32_t iteration = 0; iteration < repeats; ++iteration) {
0x000000000005ddf4 (+0x000000e8)  08863001  SUB_IMM.S64                     X3, X3, #1
0x000000000005ddf8 (+0x000000ec)  029e3a00  ZEROEXT.U32                     X15, X3
0x000000000005ddfc (+0x000000f0)  0000f21e  CMP.S64.NE                      X15, X4
0x000000000005de00 (+0x000000f4)  4020ffe7  JUMPC                           #65511
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005de04 (+0x000000f8)  07220018  MOV_XD_IMM                      X17, #24
0x000000000005de08 (+0x000000fc)  003de881  ADD.S64                         X30, X30, X17
# [DWARF] ccec/ccec_ops.h:172
#     166 | }
#     167 | 
#     168 | static __aicore__ __attribute__((noinline, used)) void pa_real_vector_mul_workload_aiv(
#     169 |     __gm__ float *input_a, __gm__ float *input_b, __gm__ float *output, uint32_t repeats
#     170 | ) {
#     171 |     RunRealVectorWorkload<true>(input_a, input_b, output, repeats);
# >   172 | }
0x000000000005de0c (+0x00000100)  1cffe868  LD_XD_XN_IMM.B64                X31, X30, #2152
0x000000000005de10 (+0x00000104)  1cfbe860  LD_XD_XN_IMM.B64                X29, X30, #2144
0x000000000005de14 (+0x00000108)  4061f000  RET
