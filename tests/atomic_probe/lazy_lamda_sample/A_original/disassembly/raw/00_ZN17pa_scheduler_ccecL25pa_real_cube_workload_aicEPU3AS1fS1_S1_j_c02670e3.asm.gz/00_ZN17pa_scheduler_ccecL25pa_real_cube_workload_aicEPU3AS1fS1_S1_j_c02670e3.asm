# schema=pa_final_linked_disassembly/v1
# variant=original
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=76c961f846c7efc89b40942c3a8113530a6da2c7bfbdc601615852f8c5b79cfc
# final_text_address=0x0
# final_text_size=780344
# final_text_sha256=018ae7dc29ce78249b2e3bff84b0faa2e671e2448c9316719fb48bc59139d2fc
# symbol=_ZN17pa_scheduler_ccecL25pa_real_cube_workload_aicEPU3AS1fS1_S1_j
# binding=LOCAL
# final_pc=0x0
# size=192
# instruction_count=48
# encoded_word_count=48
# body_sha256=b8afa7640101b76f5e91a2e172ddd1cb39b6e11ccecd0c4395057eabc1e2bc00
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction

0x0000000000000000 (+0x00000000)  028a3a00  ZEROEXT.U32                     X5, X3
0x0000000000000004 (+0x00000004)  07080000  MOV_XD_IMM                      X4, #0
0x0000000000000008 (+0x00000008)  0000520e  CMP.S64.EQ                      X5, X4
0x000000000000000c (+0x0000000c)  4020002c  JUMPC                           #44
0x0000000000000010 (+0x00000010)  070a0001  MOV_XD_IMM                      X5, #1
0x0000000000000014 (+0x00000014)  07160080  MOV_XD_IMM                      X11, #128
0x0000000000000018 (+0x00000018)  071c0800  MOV_XD_IMM                      X14, #2048
0x000000000000001c (+0x0000001c)  074b0001  MOVK                            X5, #1, #1
0x0000000000000020 (+0x00000020)  070e2000  MOV_XD_IMM                      X7, #8192
0x0000000000000024 (+0x00000024)  07100000  MOV_XD_IMM                      X8, #0
0x0000000000000028 (+0x00000028)  07120008  MOV_XD_IMM                      X9, #8
0x000000000000002c (+0x0000002c)  07140000  MOV_XD_IMM                      X10, #0
0x0000000000000030 (+0x00000030)  07578008  MOVK                            X11, #32776, #1
0x0000000000000034 (+0x00000034)  07180001  MOV_XD_IMM                      X12, #1
0x0000000000000038 (+0x00000038)  071a0080  MOV_XD_IMM                      X13, #128
0x000000000000003c (+0x0000003c)  075d0080  MOVK                            X14, #128, #1
0x0000000000000040 (+0x00000040)  078b0080  MOVK                            X5, #128, #2
0x0000000000000044 (+0x00000044)  070c0080  MOV_XD_IMM                      X6, #128
0x0000000000000048 (+0x00000048)  07cf0080  MOVK                            X7, #128, #3
0x000000000000004c (+0x0000004c)  07510002  MOVK                            X8, #2, #1
0x0000000000000050 (+0x00000050)  07530008  MOVK                            X9, #8, #1
0x0000000000000054 (+0x00000054)  07951008  MOVK                            X10, #4104, #2
0x0000000000000058 (+0x00000058)  07d7a000  MOVK                            X11, #40960, #3
0x000000000000005c (+0x0000005c)  07994000  MOVK                            X12, #16384, #2
0x0000000000000060 (+0x00000060)  079b0800  MOVK                            X13, #2048, #2
0x0000000000000064 (+0x00000064)  079d0080  MOVK                            X14, #128, #2
0x0000000000000068 (+0x00000068)  02fe5900  MOV_SPR_XN.B64                  MTE2_NZ_PARA, X5
0x000000000000006c (+0x0000006c)  6b08039a  MOV_OUT_TO_L1_MULTI_ND2NZ.B32S  X4, X0, X7, X6
0x0000000000000070 (+0x00000070)  02fe5900  MOV_SPR_XN.B64                  MTE2_NZ_PARA, X5
0x0000000000000074 (+0x00000074)  6b10139a  MOV_OUT_TO_L1_MULTI_ND2NZ.B32S  X8, X1, X7, X6
0x0000000000000078 (+0x00000078)  40a01180  SET_FLAG                        MTE2
0x000000000000007c (+0x0000007c)  40c01180  WAIT_FLAG                       MTE2
0x0000000000000080 (+0x00000080)  6cc84524  LOAD_2Dv2.B32                   X4, X4, X10, X9
0x0000000000000084 (+0x00000084)  6cc88527  LOAD_2Dv2.B32                   X4, X8, X10, X9
0x0000000000000088 (+0x00000088)  40a00d00  SET_FLAG                        MTE1
0x000000000000008c (+0x0000008c)  40c00d00  WAIT_FLAG                       MTE1
0x0000000000000090 (+0x00000090)  f088422d  MMAD                            X4, X4, X4, X11
0x0000000000000094 (+0x00000094)  40a04900  SET_FLAG                        CUBE
0x0000000000000098 (+0x00000098)  40c04900  WAIT_FLAG                       CUBE
0x000000000000009c (+0x0000009c)  02c2c900  MOV_SPR_XN.B64                  LOOP3_PARA, X12
0x00000000000000a0 (+0x000000a0)  c2044734  FIX_L0C_TO_DST
0x00000000000000a4 (+0x000000a4)  40a42803  SET_FLAG                        FIXP
0x00000000000000a8 (+0x000000a8)  40c42803  WAIT_FLAG                       FIXP
0x00000000000000ac (+0x000000ac)  08863001  SUB_IMM.S64                     X3, X3, #1
0x00000000000000b0 (+0x000000b0)  029e3a00  ZEROEXT.U32                     X15, X3
0x00000000000000b4 (+0x000000b4)  0000f21e  CMP.S64.NE                      X15, X4
0x00000000000000b8 (+0x000000b8)  4020ffec  JUMPC                           #65516
0x00000000000000bc (+0x000000bc)  4061f000  RET
