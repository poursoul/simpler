# schema=pa_final_linked_disassembly/v1
# variant=compete-first
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=82a27e206ee1b2411964c0530c73adf92a2b032ac202a7c65c6b5f7d76a4571b
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=8fd6209b2f0f9d1fb48d4d8a16cf27649e26071153b908e1e0e39ca107d63589
# symbol=_ZN3pto23TBinOps_2D_NoPostUpdateINS_5AddOpIfEEfLj64ELj8ELj128ELj128ELj128EEEvPU3AS6T0_S5_S5_jj.vector.thread
# binding=LOCAL
# final_pc=0x85a00
# size=48
# instruction_count=12
# encoded_word_count=12
# body_sha256=40cfc6402a5ba38eb3edbe949d63afe52206a592975835aa76b9f028b1d1a67a
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=rvec
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:12
#
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x0000000000085a00 (+0x00000000)  c410001d  RV_VAG                          A0, S4, S2, S0, S0
0x0000000000085a04 (+0x00000004)  c201010d  RV_SMOVI                        S65, #128
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TBinOp.hpp:79
#      73 |     __VEC_SCOPE__
#      74 |     {
#      75 |         RegTensor<T> vreg0, vreg1, vreg2;
#      76 |         MaskReg preg;
#      77 |         constexpr auto distValue =
#      78 |             std::integral_constant<::DistVST, static_cast<::DistVST>(GetDistVst<T, DistVST::DIST_NORM>())>();
# >    79 |         for (uint16_t i = 0; i < (uint16_t)(validRows); ++i) {
0x0000000000085a08 (+0x00000008)  c380219e  RV_VLOOPv2                      S7, #8, #2, #1
0x0000000000085a0c (+0x0000000c)  c708004d  RV_SMOV.B32                     S67, S65
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TBinOp.hpp:81
#      80 |             uint32_t sreg = (uint32_t)(validCols);
# >    81 |             for (uint16_t j = 0; j < (uint16_t)repeatTimes; ++j) {
0x0000000000085a10 (+0x00000010)  c300171e  RV_VLOOPv2.B32                  S6, #5, #1, #1
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:1614
#    1608 |     defined(__DAV_310R6__) || defined(__DAV_L510__) ||                         \
#    1609 |     (__NPU_ARCH__ == 5102) || (__NPU_ARCH__ == 9201) ||                        \
#    1610 |     (__NPU_ARCH__ == 9202) || (__NPU_ARCH__ == 3510) || (__NPU_ARCH__ == 5161)
#    1611 | __VF_VLDS(bfloat16_t, bf16, v128)
#    1612 | #endif
#    1613 | __VF_VLDS(half, f16, v128)
# >  1614 | __VF_VLDS(float, f32, v64)
0x0000000000085a14 (+0x00000014)  00200008  RV_VLD                          V0, [S8], A0, #NORAML
0x0000000000085a18 (+0x00000018)  02280008  RV_VLD                          V1, [S10], A0, #NORAML
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:6712
#    6706 |     scalar = ret.scalar_out;                                                   \
#    6707 |     return ret.mask;                                                           \
#    6708 |   }
#    6709 | 
#    6710 | __VF_PLT_V300(b8, uint32_t)
#    6711 | __VF_PLT_V300(b16, uint32_t)
# >  6712 | __VF_PLT_V300(b32, uint32_t)
0x0000000000085a1c (+0x0000001c)  a26c0150  RV_PLT.B32                      P1, S67
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:7309
#    7303 | __VF_MERGING_BINARY_OP(vadd, u32, u32, v64)
#    7304 | __VF_MERGING_BINARY_OP(vadd, s16, s16, v128)
#    7305 | __VF_MERGING_BINARY_OP(vadd, u16, u16, v128)
#    7306 | __VF_MERGING_BINARY_OP(vadd, s8, s8, v256)
#    7307 | __VF_MERGING_BINARY_OP(vadd, u8, u8, v256)
#    7308 | __VF_MERGING_BINARY_OP(vadd, f16, f16, v128)
# >  7309 | __VF_MERGING_BINARY_OP(vadd, f32, f32, v64)
0x0000000000085a20 (+0x00000020)  80082780  RV_VADD.F32                     V0, V0, V1, P1
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:2097
#    2091 | __VF_VSTS(vsts, uint8_t, u8, v256, NOT_DEPRECATED)
#    2092 | __VF_VSTS(vsts, int16_t, s16, v128, NOT_DEPRECATED)
#    2093 | __VF_VSTS(vsts, uint16_t, u16, v128, NOT_DEPRECATED)
#    2094 | __VF_VSTS(vsts, int32_t, s32, v64, NOT_DEPRECATED)
#    2095 | __VF_VSTS(vsts, uint32_t, u32, v64, NOT_DEPRECATED)
#    2096 | __VF_VSTS(vsts, half, f16, v128, NOT_DEPRECATED)
# >  2097 | __VF_VSTS(vsts, float, f32, v64, NOT_DEPRECATED)
0x0000000000085a24 (+0x00000024)  40300108  RV_VST                          V0, [S12], A0, P1, #NORM_B32
0x0000000000085a28 (+0x00000028)  c0000016  RV_SNOP.U16
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:0
# [SOURCE unavailable]
0x0000000000085a2c (+0x0000002c)  c0000017  RV_SEND.U16
