# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=_ZN12pa_schedulerL23WritePollBatchRecordRawEPU3AS1NS_14TraceCoreStateEPU3AS1NS_11TraceRecordEjmmjj
# binding=LOCAL
# final_pc=0x27ac0
# size=220
# instruction_count=55
# encoded_word_count=55
# body_sha256=257907e7fa33e1cc56a582855355e17e46973e11d7fa9d5c02f39f6424748c29
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction

0x0000000000027ac0 (+0x00000000)  070e0000  MOV_XD_IMM                      X7, #0
0x0000000000027ac4 (+0x00000004)  0000038e  CMP.S64.EQ                      X0, X7
0x0000000000027ac8 (+0x00000008)  4020002d  JUMPC                           #45
0x0000000000027acc (+0x0000000c)  07100000  MOV_XD_IMM                      X8, #0
0x0000000000027ad0 (+0x00000010)  0000140e  CMP.S64.EQ                      X1, X8
0x0000000000027ad4 (+0x00000014)  4020002a  JUMPC                           #42
0x0000000000027ad8 (+0x00000018)  02922a00  ZEROEXT.U32                     X9, X2
0x0000000000027adc (+0x0000001c)  0000940e  CMP.S64.EQ                      X9, X8
0x0000000000027ae0 (+0x00000020)  40200027  JUMPC                           #39
0x0000000000027ae4 (+0x00000024)  1c840000  LD_XD_XN_IMM.B32                X2, X0, #0
0x0000000000027ae8 (+0x00000028)  004024ae  CMP.U64.LT                      X2, X9
0x0000000000027aec (+0x0000002c)  40200002  JUMPC                           #2
0x0000000000027af0 (+0x00000030)  40000025  JUMP                            #37
0x0000000000027af4 (+0x00000034)  020e2800  MOV_XD_XN.S64                   X7, X2
0x0000000000027af8 (+0x00000038)  02ce0206  SHL.B64                         X7, #6
0x0000000000027afc (+0x0000003c)  00021381  ADD.S64                         X1, X1, X7
0x0000000000027b00 (+0x00000040)  09c61201  STP_XI_XJ_XN.B64                X3, X4, X1, #0
0x0000000000027b04 (+0x00000044)  07060001  MOV_XD_IMM                      X3, #1
0x0000000000027b08 (+0x00000048)  02063080  NEG.S64                         X3, X3
0x0000000000027b0c (+0x0000004c)  03c61010  ST_XD_XN_IMM.B64                X3, X1, #16
0x0000000000027b10 (+0x00000050)  0706000e  MOV_XD_IMM                      X3, #14
0x0000000000027b14 (+0x00000054)  03861018  ST_XD_XN_IMM.B32                X3, X1, #24
0x0000000000027b18 (+0x00000058)  070e000d  MOV_XD_IMM                      X7, #13
0x0000000000027b1c (+0x0000005c)  1c86001c  LD_XD_XN_IMM.B32                X3, X0, #28
0x0000000000027b20 (+0x00000060)  0386101c  ST_XD_XN_IMM.B32                X3, X1, #28
0x0000000000027b24 (+0x00000064)  1c860018  LD_XD_XN_IMM.B32                X3, X0, #24
0x0000000000027b28 (+0x00000068)  03861020  ST_XD_XN_IMM.B32                X3, X1, #32
0x0000000000027b2c (+0x0000006c)  02866a00  ZEROEXT.U32                     X3, X6
0x0000000000027b30 (+0x00000070)  1c880014  LD_XD_XN_IMM.B32                X4, X0, #20
0x0000000000027b34 (+0x00000074)  004033be  CMP.U64.GT                      X3, X7
0x0000000000027b38 (+0x00000078)  03881024  ST_XD_XN_IMM.B32                X4, X1, #36
0x0000000000027b3c (+0x0000007c)  07080090  MOV_XD_IMM                      X4, #144
0x0000000000027b40 (+0x00000080)  40200008  JUMPC                           #8
0x0000000000027b44 (+0x00000084)  0708e06c  MOV_XD_IMM                      X4, #57452
0x0000000000027b48 (+0x00000088)  07490005  MOVK                            X4, #5, #1
0x0000000000027b4c (+0x0000008c)  07890000  MOVK                            X4, #0, #2
0x0000000000027b50 (+0x00000090)  07c90000  MOVK                            X4, #0, #3
0x0000000000027b54 (+0x00000094)  020e0880  MOV_XD_SPR.S64                  X7, PC
0x0000000000027b58 (+0x00000098)  00084381  ADD.S64                         X4, X4, X7
0x0000000000027b5c (+0x0000009c)  01884180  LD_XD_XN.B32                    X4, X4, X3
0x0000000000027b60 (+0x000000a0)  02ca0208  SHL.B64                         X5, #8
0x0000000000027b64 (+0x000000a4)  00c6428b  OR.B64                          X3, X4, X5
0x0000000000027b68 (+0x000000a8)  08021028  ADD_IMM.S64                     X1, X1, #40
0x0000000000027b6c (+0x000000ac)  09861301  STP_XI_XJ_XN.B32                X3, X6, X1, #0
0x0000000000027b70 (+0x000000b0)  08022001  ADD_IMM.S64                     X1, X2, #1
0x0000000000027b74 (+0x000000b4)  070e0001  MOV_XD_IMM                      X7, #1
0x0000000000027b78 (+0x000000b8)  03820000  ST_XD_XN_IMM.B32                X1, X0, #0
0x0000000000027b7c (+0x000000bc)  02007800  MOV_XD_XN.S64                   X0, X7
0x0000000000027b80 (+0x000000c0)  4061f000  RET
0x0000000000027b84 (+0x000000c4)  1c820004  LD_XD_XN_IMM.B32                X1, X0, #4
0x0000000000027b88 (+0x000000c8)  070e0000  MOV_XD_IMM                      X7, #0
0x0000000000027b8c (+0x000000cc)  08021001  ADD_IMM.S64                     X1, X1, #1
0x0000000000027b90 (+0x000000d0)  03820004  ST_XD_XN_IMM.B32                X1, X0, #4
0x0000000000027b94 (+0x000000d4)  02007800  MOV_XD_XN.S64                   X0, X7
0x0000000000027b98 (+0x000000d8)  4061f000  RET
