# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=pa_execute_real_winner_workload_aic
# binding=LOCAL
# final_pc=0x130
# size=400
# instruction_count=100
# encoded_word_count=100
# body_sha256=88b6e6169f66470b7d9746ae3b1dc48a5e2bf4bd46994a85cc37926c394adeb6
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:100
#
# [DWARF] ccec/ccec_ops.h:355
#     349 | // 跨 TU 只暴露按架构区分的真实负载分派；Cube/Vector 实体仍保持 LOCAL。
#     350 | // 最终 mixed ELF 由 version script 把该 strong 定义重新局部化，避免成为 kernel entry。
#     351 | #if defined(PA_BUILD_AIC)
#     352 | extern "C" __attribute__((noinline, used)) __aicore__ void pa_execute_real_winner_workload_aic(
#     353 |     __gm__ pa_scheduler::SchedulerState *state, __gm__ pa_scheduler::WorkerState *worker,
#     354 |     pa_scheduler::TaskKind kind
# >   355 | ) {
0x0000000000000130 (+0x00000000)  072207a0  MOV_XD_IMM                      X17, #1952
0x0000000000000134 (+0x00000004)  03ffe868  ST_XD_XN_IMM.B64                X31, X30, #2152
0x0000000000000138 (+0x00000008)  03fbe860  ST_XD_XN_IMM.B64                X29, X30, #2144
0x000000000000013c (+0x0000000c)  003be882  SUB.S64                         X29, X30, X17
0x0000000000000140 (+0x00000010)  07220018  MOV_XD_IMM                      X17, #24
0x0000000000000144 (+0x00000014)  003de882  SUB.S64                         X30, X30, X17
# [DWARF] common/pa_scheduler_core.h:128
#     122 |         default:
#     123 |             return 0;
#     124 |     }
#     125 | }
#     126 | 
#     127 | PA_DEVICE uint32_t WorkloadCountForKind(PA_GM const WorkloadCounts &counts, TaskKind kind) {
# >   128 |     switch (kind) {
0x0000000000000148 (+0x00000018)  08862001  SUB_IMM.S64                     X3, X2, #1
0x000000000000014c (+0x0000001c)  02863a00  ZEROEXT.U32                     X3, X3
0x0000000000000150 (+0x00000020)  07080003  MOV_XD_IMM                      X4, #3
0x0000000000000154 (+0x00000024)  0040323e  CMP.U64.GT                      X3, X4
0x0000000000000158 (+0x00000028)  02080800  MOV_XD_XN.S64                   X4, X0
0x000000000000015c (+0x0000002c)  4020000c  JUMPC                           #12
# [DWARF] common/pa_scheduler_core.h:0
# [SOURCE unavailable]
0x0000000000000160 (+0x00000030)  070059c8  MOV_XD_IMM                      X0, #22984
0x0000000000000164 (+0x00000034)  07410008  MOVK                            X0, #8, #1
0x0000000000000168 (+0x00000038)  07810000  MOVK                            X0, #0, #2
0x000000000000016c (+0x0000003c)  07c10000  MOVK                            X0, #0, #3
0x0000000000000170 (+0x00000040)  020a0880  MOV_XD_SPR.S64                  X5, PC
0x0000000000000174 (+0x00000044)  00000281  ADD.S64                         X0, X0, X5
0x0000000000000178 (+0x00000048)  01800180  LD_XD_XN.B32                    X0, X0, X3
0x000000000000017c (+0x0000004c)  02800980  SIGNEXT.S32                     X0, X0
0x0000000000000180 (+0x00000050)  40020000  JUMP                            X0, #0
0x0000000000000184 (+0x00000054)  0700f748  MOV_XD_IMM                      X0, #63304
0x0000000000000188 (+0x00000058)  40000008  JUMP                            #8
0x000000000000018c (+0x0000005c)  07060000  MOV_XD_IMM                      X3, #0
0x0000000000000190 (+0x00000060)  40000009  JUMP                            #9
0x0000000000000194 (+0x00000064)  0700f74c  MOV_XD_IMM                      X0, #63308
0x0000000000000198 (+0x00000068)  40000004  JUMP                            #4
0x000000000000019c (+0x0000006c)  0700f750  MOV_XD_IMM                      X0, #63312
0x00000000000001a0 (+0x00000070)  40000002  JUMP                            #2
0x00000000000001a4 (+0x00000074)  0700f754  MOV_XD_IMM                      X0, #63316
0x00000000000001a8 (+0x00000078)  07413c05  MOVK                            X0, #15365, #1
0x00000000000001ac (+0x0000007c)  00004001  ADD.S64                         X0, X4, X0
0x00000000000001b0 (+0x00000080)  1c860000  LD_XD_XN_IMM.B32                X3, X0, #0
0x00000000000001b4 (+0x00000084)  0700f744  MOV_XD_IMM                      X0, #63300
0x00000000000001b8 (+0x00000088)  07413c05  MOVK                            X0, #15365, #1
# [DWARF] ccec/ccec_ops.h:369
#     363 |     const uint32_t repeats = pa_scheduler::WorkloadCountForKind(
#     364 |         state->winner_workload.repeats, kind
#     365 |     );
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
# >   369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
0x00000000000001bc (+0x0000008c)  00004001  ADD.S64                         X0, X4, X0
0x00000000000001c0 (+0x00000090)  1c800000  LD_XD_XN_IMM.B32                X0, X0, #0
0x00000000000001c4 (+0x00000094)  070a0001  MOV_XD_IMM                      X5, #1
0x00000000000001c8 (+0x00000098)  0000029e  CMP.S64.NE                      X0, X5
0x00000000000001cc (+0x0000009c)  40200038  JUMPC                           #56
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x00000000000001d0 (+0x000000a0)  0700f758  MOV_XD_IMM                      X0, #63320
0x00000000000001d4 (+0x000000a4)  07413c05  MOVK                            X0, #15365, #1
0x00000000000001d8 (+0x000000a8)  00004001  ADD.S64                         X0, X4, X0
0x00000000000001dc (+0x000000ac)  1cc00000  LD_XD_XN_IMM.B64                X0, X0, #0
0x00000000000001e0 (+0x000000b0)  070a0000  MOV_XD_IMM                      X5, #0
# [DWARF] ccec/ccec_ops.h:369
#     363 |     const uint32_t repeats = pa_scheduler::WorkloadCountForKind(
#     364 |         state->winner_workload.repeats, kind
#     365 |     );
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
# >   369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
0x00000000000001e4 (+0x000000b4)  0000028e  CMP.S64.EQ                      X0, X5
0x00000000000001e8 (+0x000000b8)  40200031  JUMPC                           #49
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x00000000000001ec (+0x000000bc)  070af760  MOV_XD_IMM                      X5, #63328
0x00000000000001f0 (+0x000000c0)  074b3c05  MOVK                            X5, #15365, #1
# [DWARF] ccec/ccec_ops.h:371
#     365 |     );
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
#     369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
#     370 |         workspace == 0 ||
# >   371 |         state->winner_workload.workspace_bytes < pa_scheduler::winner_workload::kWorkspaceBytes ||
0x00000000000001f4 (+0x000000c4)  00084281  ADD.S64                         X4, X4, X5
0x00000000000001f8 (+0x000000c8)  1cc84000  LD_XD_XN_IMM.B64                X4, X4, #0
0x00000000000001fc (+0x000000cc)  070a0000  MOV_XD_IMM                      X5, #0
0x0000000000000200 (+0x000000d0)  074b00c2  MOVK                            X5, #194, #1
0x0000000000000204 (+0x000000d4)  004042ae  CMP.U64.LT                      X4, X5
0x0000000000000208 (+0x000000d8)  40200029  JUMPC                           #41
# [DWARF] ccec/ccec_ops.h:372
# >   372 |         worker->core_idx < 0 || static_cast<uint32_t>(worker->core_idx) >= pa_scheduler::kWorkers ||
0x000000000000020c (+0x000000dc)  1c881004  LD_XD_XN_IMM.B32                X4, X1, #4
0x0000000000000210 (+0x000000e0)  070a0000  MOV_XD_IMM                      X5, #0
0x0000000000000214 (+0x000000e4)  02824980  SIGNEXT.S32                     X1, X4
0x0000000000000218 (+0x000000e8)  000012ae  CMP.S64.LT                      X1, X5
0x000000000000021c (+0x000000ec)  40200024  JUMPC                           #36
0x0000000000000220 (+0x000000f0)  08823081  SUB_IMM.S64                     X1, X3, #129
0x0000000000000224 (+0x000000f4)  070aff80  MOV_XD_IMM                      X5, #65408
0x0000000000000228 (+0x000000f8)  02821a00  ZEROEXT.U32                     X1, X1
0x000000000000022c (+0x000000fc)  074bffff  MOVK                            X5, #65535, #1
0x0000000000000230 (+0x00000100)  004012ae  CMP.U64.LT                      X1, X5
0x0000000000000234 (+0x00000104)  4020001e  JUMPC                           #30
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x0000000000000238 (+0x00000108)  02824a00  ZEROEXT.U32                     X1, X4
0x000000000000023c (+0x0000010c)  070a005f  MOV_XD_IMM                      X5, #95
# [DWARF] ccec/ccec_ops.h:372
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
#     369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
#     370 |         workspace == 0 ||
#     371 |         state->winner_workload.workspace_bytes < pa_scheduler::winner_workload::kWorkspaceBytes ||
# >   372 |         worker->core_idx < 0 || static_cast<uint32_t>(worker->core_idx) >= pa_scheduler::kWorkers ||
0x0000000000000240 (+0x00000110)  004012be  CMP.U64.GT                      X1, X5
0x0000000000000244 (+0x00000114)  4020001a  JUMPC                           #26
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x0000000000000248 (+0x00000118)  07020001  MOV_XD_IMM                      X1, #1
# [DWARF] ccec/ccec_ops.h:377
#     371 |         state->winner_workload.workspace_bytes < pa_scheduler::winner_workload::kWorkspaceBytes ||
#     372 |         worker->core_idx < 0 || static_cast<uint32_t>(worker->core_idx) >= pa_scheduler::kWorkers ||
#     373 |         repeats == 0 || repeats > pa_scheduler::winner_workload::kMaxRealComputeCount) {
#     374 |         return;
#     375 |     }
#     376 | #if defined(PA_BUILD_AIC)
# >   377 |     if (kind != pa_scheduler::TaskKind::Qk && kind != pa_scheduler::TaskKind::Pv) return;
0x000000000000024c (+0x0000011c)  020a2800  MOV_XD_XN.S64                   X5, X2
0x0000000000000250 (+0x00000120)  02ca1440  SBITSET.B64                     X5, X1
0x0000000000000254 (+0x00000124)  02825a00  ZEROEXT.U32                     X1, X5
0x0000000000000258 (+0x00000128)  070a0003  MOV_XD_IMM                      X5, #3
0x000000000000025c (+0x0000012c)  0000128e  CMP.S64.EQ                      X1, X5
0x0000000000000260 (+0x00000130)  40200002  JUMPC                           #2
0x0000000000000264 (+0x00000134)  40000012  JUMP                            #18
# [DWARF] ccec/ccec_ops.h:386
#     378 | #elif defined(PA_BUILD_AIV)
#     379 |     if (kind != pa_scheduler::TaskKind::Sf && kind != pa_scheduler::TaskKind::Up) return;
#     380 | #endif
#     381 |     __gm__ float *input_a = reinterpret_cast<__gm__ float *>(workspace);
#     382 |     __gm__ float *input_b = reinterpret_cast<__gm__ float *>(
#     383 |         workspace + pa_scheduler::winner_workload::kTileBytes
#     384 |     );
#     385 |     const uint32_t kind_slot =
# >   386 |         (kind == pa_scheduler::TaskKind::Pv || kind == pa_scheduler::TaskKind::Up) ? 1U : 0U;
0x0000000000000268 (+0x00000138)  08842003  SUB_IMM.S64                     X2, X2, #3
0x000000000000026c (+0x0000013c)  02842a00  ZEROEXT.U32                     X2, X2
0x0000000000000270 (+0x00000140)  070a0002  MOV_XD_IMM                      X5, #2
0x0000000000000274 (+0x00000144)  004422af  CMPN.U64.LT                     X2, X2, X5
# [DWARF] ccec/ccec_ops.h:389
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
# >   389 |         static_cast<uint32_t>(worker->core_idx) *
0x0000000000000278 (+0x00000148)  02c80201  SHL.B64                         X4, #1
# [DWARF] ccec/ccec_ops.h:388
#     382 |     __gm__ float *input_b = reinterpret_cast<__gm__ float *>(
#     383 |         workspace + pa_scheduler::winner_workload::kTileBytes
#     384 |     );
#     385 |     const uint32_t kind_slot =
#     386 |         (kind == pa_scheduler::TaskKind::Pv || kind == pa_scheduler::TaskKind::Up) ? 1U : 0U;
#     387 |     const uint32_t output_tile =
# >   388 |         pa_scheduler::winner_workload::kSharedInputTiles +
0x000000000000027c (+0x0000014c)  00c4410b  OR.B64                          X2, X4, X2
# [DWARF] ccec/ccec_ops.h:390
#     389 |         static_cast<uint32_t>(worker->core_idx) *
# >   390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
0x0000000000000280 (+0x00000150)  08042002  ADD_IMM.S64                     X2, X2, #2
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x0000000000000284 (+0x00000154)  07020000  MOV_XD_IMM                      X1, #0
# [DWARF] ccec/ccec_ops.h:393
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
#     389 |         static_cast<uint32_t>(worker->core_idx) *
#     390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
#     391 |         kind_slot;
#     392 |     __gm__ float *output = reinterpret_cast<__gm__ float *>(
# >   393 |         workspace + static_cast<uint64_t>(output_tile) *
0x0000000000000288 (+0x00000158)  02842a00  ZEROEXT.U32                     X2, X2
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000000028c (+0x0000015c)  07430001  MOVK                            X1, #1, #1
# [DWARF] ccec/ccec_ops.h:393
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
#     389 |         static_cast<uint32_t>(worker->core_idx) *
#     390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
#     391 |         kind_slot;
#     392 |     __gm__ float *output = reinterpret_cast<__gm__ float *>(
# >   393 |         workspace + static_cast<uint64_t>(output_tile) *
0x0000000000000290 (+0x00000160)  02c40210  SHL.B64                         X2, #16
# [DWARF] ccec/ccec_ops.h:383
#     377 |     if (kind != pa_scheduler::TaskKind::Qk && kind != pa_scheduler::TaskKind::Pv) return;
#     378 | #elif defined(PA_BUILD_AIV)
#     379 |     if (kind != pa_scheduler::TaskKind::Sf && kind != pa_scheduler::TaskKind::Up) return;
#     380 | #endif
#     381 |     __gm__ float *input_a = reinterpret_cast<__gm__ float *>(workspace);
#     382 |     __gm__ float *input_b = reinterpret_cast<__gm__ float *>(
# >   383 |         workspace + pa_scheduler::winner_workload::kTileBytes
0x0000000000000294 (+0x00000164)  00020081  ADD.S64                         X1, X0, X1
# [DWARF] ccec/ccec_ops.h:393
#     384 |     );
#     385 |     const uint32_t kind_slot =
#     386 |         (kind == pa_scheduler::TaskKind::Pv || kind == pa_scheduler::TaskKind::Up) ? 1U : 0U;
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
#     389 |         static_cast<uint32_t>(worker->core_idx) *
#     390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
#     391 |         kind_slot;
#     392 |     __gm__ float *output = reinterpret_cast<__gm__ float *>(
# >   393 |         workspace + static_cast<uint64_t>(output_tile) *
0x0000000000000298 (+0x00000168)  00042001  ADD.S64                         X2, X2, X0
# [DWARF] ccec/ccec_ops.h:397
#     394 |             pa_scheduler::winner_workload::kTileBytes
#     395 |     );
#     396 | #if defined(PA_BUILD_AIC)
# >   397 |     pa_scheduler_ccec::pa_real_cube_workload_aic(input_a, input_b, output, repeats);
0x000000000000029c (+0x0000016c)  0708ff72  MOV_XD_IMM                      X4, #65394
0x00000000000002a0 (+0x00000170)  0749ffff  MOVK                            X4, #65535, #1
0x00000000000002a4 (+0x00000174)  0789ffff  MOVK                            X4, #65535, #2
0x00000000000002a8 (+0x00000178)  40424000  CALL                            X4, #0
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x00000000000002ac (+0x0000017c)  07220018  MOV_XD_IMM                      X17, #24
0x00000000000002b0 (+0x00000180)  003de881  ADD.S64                         X30, X30, X17
# [DWARF] ccec/ccec_ops.h:405
#     399 |     if (kind == pa_scheduler::TaskKind::Sf) {
#     400 |         pa_scheduler_ccec::pa_real_vector_add_workload_aiv(input_a, input_b, output, repeats);
#     401 |     } else {
#     402 |         pa_scheduler_ccec::pa_real_vector_mul_workload_aiv(input_a, input_b, output, repeats);
#     403 |     }
#     404 | #endif
# >   405 | }
0x00000000000002b4 (+0x00000184)  1cffe868  LD_XD_XN_IMM.B64                X31, X30, #2152
0x00000000000002b8 (+0x00000188)  1cfbe860  LD_XD_XN_IMM.B64                X29, X30, #2144
0x00000000000002bc (+0x0000018c)  4061f000  RET
