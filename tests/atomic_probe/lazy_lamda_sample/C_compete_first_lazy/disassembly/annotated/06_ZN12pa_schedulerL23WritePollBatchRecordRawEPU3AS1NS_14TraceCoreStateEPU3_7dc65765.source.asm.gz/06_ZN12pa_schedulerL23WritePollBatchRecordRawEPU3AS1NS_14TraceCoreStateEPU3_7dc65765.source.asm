# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=_ZN12pa_schedulerL23WritePollBatchRecordRawEPU3AS1NS_14TraceCoreStateEPU3AS1NS_11TraceRecordEjmmjj
# binding=LOCAL
# final_pc=0x429d0
# size=220
# instruction_count=55
# encoded_word_count=55
# body_sha256=422635da4a38494a486262b1261ddcd2127aa8aac6f695aee3bea17bebe7f36c
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:55
#
# [DWARF] common/pa_trace.h:181
#     175 | // CCEC 不让栈上的 TraceContext/WorkerResult 引用跨非内联调用。这里仅把
#     176 | // PollBatch 固定形状的 64-byte GM 写入抽成共享函数，以抑制各 phase 边界
#     177 | // 内联后的代码膨胀；参数只有 GM 指针与标量，局部 batch 状态仍由调用者维护。
#     178 | PA_DEVICE_NOINLINE bool WritePollBatchRecordRaw(
#     179 |     PA_GM TraceCoreState *core, PA_GM TraceRecord *records, uint32_t capacity,
#     180 |     uint64_t start_cycle, uint64_t end_cycle, uint32_t call_count, uint32_t site_id
# >   181 | ) {
0x00000000000429d0 (+0x00000000)  070e0000  MOV_XD_IMM                      X7, #0
# [DWARF] common/pa_trace.h:192
#     182 | #if PA_BUILD_SUBMIT_PMU
#     183 |     (void)core;
#     184 |     (void)records;
#     185 |     (void)capacity;
#     186 |     (void)start_cycle;
#     187 |     (void)end_cycle;
#     188 |     (void)call_count;
#     189 |     (void)site_id;
#     190 |     return false;
#     191 | #else
# >   192 |     if (core == nullptr || records == nullptr || capacity == 0) {
0x00000000000429d4 (+0x00000004)  0000038e  CMP.S64.EQ                      X0, X7
0x00000000000429d8 (+0x00000008)  4020002d  JUMPC                           #45
# [DWARF] common/pa_trace.h:0
# [SOURCE unavailable]
0x00000000000429dc (+0x0000000c)  07100000  MOV_XD_IMM                      X8, #0
# [DWARF] common/pa_trace.h:192
#     186 |     (void)start_cycle;
#     187 |     (void)end_cycle;
#     188 |     (void)call_count;
#     189 |     (void)site_id;
#     190 |     return false;
#     191 | #else
# >   192 |     if (core == nullptr || records == nullptr || capacity == 0) {
0x00000000000429e0 (+0x00000010)  0000140e  CMP.S64.EQ                      X1, X8
0x00000000000429e4 (+0x00000014)  4020002a  JUMPC                           #42
# [DWARF] common/pa_trace.h:0
# [SOURCE unavailable]
0x00000000000429e8 (+0x00000018)  02922a00  ZEROEXT.U32                     X9, X2
# [DWARF] common/pa_trace.h:192
#     186 |     (void)start_cycle;
#     187 |     (void)end_cycle;
#     188 |     (void)call_count;
#     189 |     (void)site_id;
#     190 |     return false;
#     191 | #else
# >   192 |     if (core == nullptr || records == nullptr || capacity == 0) {
0x00000000000429ec (+0x0000001c)  0000940e  CMP.S64.EQ                      X9, X8
0x00000000000429f0 (+0x00000020)  40200027  JUMPC                           #39
# [DWARF] common/pa_trace.h:195
#     193 |         return false;
#     194 |     }
# >   195 |     const uint32_t slot = core->count;
0x00000000000429f4 (+0x00000024)  1c840000  LD_XD_XN_IMM.B32                X2, X0, #0
# [DWARF] common/pa_trace.h:196
# >   196 |     if (slot >= capacity) {
0x00000000000429f8 (+0x00000028)  004024ae  CMP.U64.LT                      X2, X9
0x00000000000429fc (+0x0000002c)  40200002  JUMPC                           #2
0x0000000000042a00 (+0x00000030)  40000025  JUMP                            #37
# [DWARF] common/pa_trace.h:200
#     197 |         core->dropped = core->dropped + 1;
#     198 |         return false;
#     199 |     }
# >   200 |     PA_GM TraceRecord &record = records[slot];
0x0000000000042a04 (+0x00000034)  020e2800  MOV_XD_XN.S64                   X7, X2
0x0000000000042a08 (+0x00000038)  02ce0206  SHL.B64                         X7, #6
0x0000000000042a0c (+0x0000003c)  00021381  ADD.S64                         X1, X1, X7
# [DWARF] common/pa_trace.h:201
# >   201 |     record.start_cycle = start_cycle;
0x0000000000042a10 (+0x00000040)  09c61201  STP_XI_XJ_XN.B64                X3, X4, X1, #0
0x0000000000042a14 (+0x00000044)  07060001  MOV_XD_IMM                      X3, #1
# [DWARF] common/pa_trace.h:0
# [SOURCE unavailable]
0x0000000000042a18 (+0x00000048)  02063080  NEG.S64                         X3, X3
# [DWARF] common/pa_trace.h:203
#     197 |         core->dropped = core->dropped + 1;
#     198 |         return false;
#     199 |     }
#     200 |     PA_GM TraceRecord &record = records[slot];
#     201 |     record.start_cycle = start_cycle;
#     202 |     record.end_cycle = end_cycle;
# >   203 |     record.task_id = -1;
0x0000000000042a1c (+0x0000004c)  03c61010  ST_XD_XN_IMM.B64                X3, X1, #16
0x0000000000042a20 (+0x00000050)  0706000e  MOV_XD_IMM                      X3, #14
# [DWARF] common/pa_trace.h:205
#     204 |     record.function_id = -1;
# >   205 |     record.phase = static_cast<int32_t>(TracePhase::Atomic);
0x0000000000042a24 (+0x00000054)  03861018  ST_XD_XN_IMM.B32                X3, X1, #24
0x0000000000042a28 (+0x00000058)  070e000d  MOV_XD_IMM                      X7, #13
# [DWARF] common/pa_trace.h:206
# >   206 |     record.lane = core->lane;
0x0000000000042a2c (+0x0000005c)  1c86001c  LD_XD_XN_IMM.B32                X3, X0, #28
0x0000000000042a30 (+0x00000060)  0386101c  ST_XD_XN_IMM.B32                X3, X1, #28
# [DWARF] common/pa_trace.h:207
# >   207 |     record.block_id = core->block_id;
0x0000000000042a34 (+0x00000064)  1c860018  LD_XD_XN_IMM.B32                X3, X0, #24
0x0000000000042a38 (+0x00000068)  03861020  ST_XD_XN_IMM.B32                X3, X1, #32
# [DWARF] common/pa_trace.h:62
#      56 | };
#      57 | 
#      58 | // pa_model.h 也向 host 暴露同一 raw ABI 映射，但 CCEC/AscendC 的单个 TU
#      59 | // 会先以 host 语境包含该头，再实例化 device 调度器。这里保留明确的 device
#      60 | // 版本，避免设备函数误调用先前已实例化的 __host__ helper。
#      61 | PA_DEVICE AtomicOp TraceAtomicSiteExpectedOp(AtomicSite site) {
# >    62 |     switch (site) {
0x0000000000042a3c (+0x0000006c)  02866a00  ZEROEXT.U32                     X3, X6
# [DWARF] common/pa_trace.h:208
#     202 |     record.end_cycle = end_cycle;
#     203 |     record.task_id = -1;
#     204 |     record.function_id = -1;
#     205 |     record.phase = static_cast<int32_t>(TracePhase::Atomic);
#     206 |     record.lane = core->lane;
#     207 |     record.block_id = core->block_id;
# >   208 |     record.core_idx = core->core_idx;
0x0000000000042a40 (+0x00000070)  1c880014  LD_XD_XN_IMM.B32                X4, X0, #20
# [DWARF] common/pa_trace.h:62
#      56 | };
#      57 | 
#      58 | // pa_model.h 也向 host 暴露同一 raw ABI 映射，但 CCEC/AscendC 的单个 TU
#      59 | // 会先以 host 语境包含该头，再实例化 device 调度器。这里保留明确的 device
#      60 | // 版本，避免设备函数误调用先前已实例化的 __host__ helper。
#      61 | PA_DEVICE AtomicOp TraceAtomicSiteExpectedOp(AtomicSite site) {
# >    62 |     switch (site) {
0x0000000000042a44 (+0x00000074)  004033be  CMP.U64.GT                      X3, X7
# [DWARF] common/pa_trace.h:208
#     202 |     record.end_cycle = end_cycle;
#     203 |     record.task_id = -1;
#     204 |     record.function_id = -1;
#     205 |     record.phase = static_cast<int32_t>(TracePhase::Atomic);
#     206 |     record.lane = core->lane;
#     207 |     record.block_id = core->block_id;
# >   208 |     record.core_idx = core->core_idx;
0x0000000000042a48 (+0x00000078)  03881024  ST_XD_XN_IMM.B32                X4, X1, #36
# [DWARF] common/pa_trace.h:0
# [SOURCE unavailable]
0x0000000000042a4c (+0x0000007c)  07080090  MOV_XD_IMM                      X4, #144
# [DWARF] common/pa_trace.h:62
#      56 | };
#      57 | 
#      58 | // pa_model.h 也向 host 暴露同一 raw ABI 映射，但 CCEC/AscendC 的单个 TU
#      59 | // 会先以 host 语境包含该头，再实例化 device 调度器。这里保留明确的 device
#      60 | // 版本，避免设备函数误调用先前已实例化的 __host__ helper。
#      61 | PA_DEVICE AtomicOp TraceAtomicSiteExpectedOp(AtomicSite site) {
# >    62 |     switch (site) {
0x0000000000042a50 (+0x00000080)  40200008  JUMPC                           #8
0x0000000000042a54 (+0x00000084)  0708323c  MOV_XD_IMM                      X4, #12860
0x0000000000042a58 (+0x00000088)  07490004  MOVK                            X4, #4, #1
0x0000000000042a5c (+0x0000008c)  07890000  MOVK                            X4, #0, #2
0x0000000000042a60 (+0x00000090)  07c90000  MOVK                            X4, #0, #3
0x0000000000042a64 (+0x00000094)  020e0880  MOV_XD_SPR.S64                  X7, PC
0x0000000000042a68 (+0x00000098)  00084381  ADD.S64                         X4, X4, X7
0x0000000000042a6c (+0x0000009c)  01884180  LD_XD_XN.B32                    X4, X4, X3
# [DWARF] common/pa_trace.h:212
#     206 |     record.lane = core->lane;
#     207 |     record.block_id = core->block_id;
#     208 |     record.core_idx = core->core_idx;
#     209 |     const AtomicSite site = static_cast<AtomicSite>(site_id);
#     210 |     record.flags = static_cast<uint32_t>(TraceAtomicSiteExpectedOp(site)) |
#     211 |                    kAtomicResultUsed | kAtomicPollBatch |
# >   212 |                    (call_count << kAtomicPollCountShift);
0x0000000000042a70 (+0x000000a0)  02ca0208  SHL.B64                         X5, #8
# [DWARF] common/pa_trace.h:211
#     205 |     record.phase = static_cast<int32_t>(TracePhase::Atomic);
#     206 |     record.lane = core->lane;
#     207 |     record.block_id = core->block_id;
#     208 |     record.core_idx = core->core_idx;
#     209 |     const AtomicSite site = static_cast<AtomicSite>(site_id);
#     210 |     record.flags = static_cast<uint32_t>(TraceAtomicSiteExpectedOp(site)) |
# >   211 |                    kAtomicResultUsed | kAtomicPollBatch |
0x0000000000042a74 (+0x000000a4)  00c6428b  OR.B64                          X3, X4, X5
# [DWARF] common/pa_trace.h:210
#     204 |     record.function_id = -1;
#     205 |     record.phase = static_cast<int32_t>(TracePhase::Atomic);
#     206 |     record.lane = core->lane;
#     207 |     record.block_id = core->block_id;
#     208 |     record.core_idx = core->core_idx;
#     209 |     const AtomicSite site = static_cast<AtomicSite>(site_id);
# >   210 |     record.flags = static_cast<uint32_t>(TraceAtomicSiteExpectedOp(site)) |
0x0000000000042a78 (+0x000000a8)  08021028  ADD_IMM.S64                     X1, X1, #40
0x0000000000042a7c (+0x000000ac)  09861301  STP_XI_XJ_XN.B32                X3, X6, X1, #0
# [DWARF] common/pa_trace.h:215
#     211 |                    kAtomicResultUsed | kAtomicPollBatch |
#     212 |                    (call_count << kAtomicPollCountShift);
#     213 |     record.auxiliary = site_id;
#     214 |     // count 最后更新，使其始终指向下一空槽；单写者条件下无需 reserve/commit 两阶段。
# >   215 |     core->count = slot + 1;
0x0000000000042a80 (+0x000000b0)  08022001  ADD_IMM.S64                     X1, X2, #1
0x0000000000042a84 (+0x000000b4)  070e0001  MOV_XD_IMM                      X7, #1
0x0000000000042a88 (+0x000000b8)  03820000  ST_XD_XN_IMM.B32                X1, X0, #0
# [DWARF] common/pa_trace.h:218
#     216 |     return true;
#     217 | #endif
# >   218 | }
0x0000000000042a8c (+0x000000bc)  02007800  MOV_XD_XN.S64                   X0, X7
0x0000000000042a90 (+0x000000c0)  4061f000  RET
# [DWARF] common/pa_trace.h:197
#     191 | #else
#     192 |     if (core == nullptr || records == nullptr || capacity == 0) {
#     193 |         return false;
#     194 |     }
#     195 |     const uint32_t slot = core->count;
#     196 |     if (slot >= capacity) {
# >   197 |         core->dropped = core->dropped + 1;
0x0000000000042a94 (+0x000000c4)  1c820004  LD_XD_XN_IMM.B32                X1, X0, #4
# [DWARF] common/pa_trace.h:0
# [SOURCE unavailable]
0x0000000000042a98 (+0x000000c8)  070e0000  MOV_XD_IMM                      X7, #0
# [DWARF] common/pa_trace.h:197
#     191 | #else
#     192 |     if (core == nullptr || records == nullptr || capacity == 0) {
#     193 |         return false;
#     194 |     }
#     195 |     const uint32_t slot = core->count;
#     196 |     if (slot >= capacity) {
# >   197 |         core->dropped = core->dropped + 1;
0x0000000000042a9c (+0x000000cc)  08021001  ADD_IMM.S64                     X1, X1, #1
0x0000000000042aa0 (+0x000000d0)  03820004  ST_XD_XN_IMM.B32                X1, X0, #4
# [DWARF] common/pa_trace.h:218
#     212 |                    (call_count << kAtomicPollCountShift);
#     213 |     record.auxiliary = site_id;
#     214 |     // count 最后更新，使其始终指向下一空槽；单写者条件下无需 reserve/commit 两阶段。
#     215 |     core->count = slot + 1;
#     216 |     return true;
#     217 | #endif
# >   218 | }
0x0000000000042aa4 (+0x000000d4)  02007800  MOV_XD_XN.S64                   X0, X7
0x0000000000042aa8 (+0x000000d8)  4061f000  RET
