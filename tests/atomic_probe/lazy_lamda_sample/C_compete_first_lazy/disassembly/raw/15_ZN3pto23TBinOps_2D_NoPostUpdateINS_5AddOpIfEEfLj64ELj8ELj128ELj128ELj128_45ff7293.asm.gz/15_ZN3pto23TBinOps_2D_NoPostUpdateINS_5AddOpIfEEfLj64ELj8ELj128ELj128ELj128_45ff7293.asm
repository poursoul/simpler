# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=_ZN3pto23TBinOps_2D_NoPostUpdateINS_5AddOpIfEEfLj64ELj8ELj128ELj128ELj128EEEvPU3AS6T0_S5_S5_jj.vector.thread
# binding=LOCAL
# final_pc=0x85a00
# size=48
# instruction_count=12
# encoded_word_count=12
# body_sha256=40cfc6402a5ba38eb3edbe949d63afe52206a592975835aa76b9f028b1d1a67a
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=rvec
# columns=final_pc function_relative_offset machine_word instruction

0x0000000000085a00 (+0x00000000)  c410001d  RV_VAG                          A0, S4, S2, S0, S0
0x0000000000085a04 (+0x00000004)  c201010d  RV_SMOVI                        S65, #128
0x0000000000085a08 (+0x00000008)  c380219e  RV_VLOOPv2                      S7, #8, #2, #1
0x0000000000085a0c (+0x0000000c)  c708004d  RV_SMOV.B32                     S67, S65
0x0000000000085a10 (+0x00000010)  c300171e  RV_VLOOPv2.B32                  S6, #5, #1, #1
0x0000000000085a14 (+0x00000014)  00200008  RV_VLD                          V0, [S8], A0, #NORAML
0x0000000000085a18 (+0x00000018)  02280008  RV_VLD                          V1, [S10], A0, #NORAML
0x0000000000085a1c (+0x0000001c)  a26c0150  RV_PLT.B32                      P1, S67
0x0000000000085a20 (+0x00000020)  80082780  RV_VADD.F32                     V0, V0, V1, P1
0x0000000000085a24 (+0x00000024)  40300108  RV_VST                          V0, [S12], A0, P1, #NORM_B32
0x0000000000085a28 (+0x00000028)  c0000016  RV_SNOP.U16
0x0000000000085a2c (+0x0000002c)  c0000017  RV_SEND.U16
