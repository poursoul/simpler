# schema=pa_final_linked_disassembly/v1
# variant=original
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=76c961f846c7efc89b40942c3a8113530a6da2c7bfbdc601615852f8c5b79cfc
# final_text_address=0x0
# final_text_size=780344
# final_text_sha256=018ae7dc29ce78249b2e3bff84b0faa2e671e2448c9316719fb48bc59139d2fc
# symbol=_ZN12pa_schedulerL23WritePollBatchRecordRawEPU3AS1NS_14TraceCoreStateEPU3AS1NS_11TraceRecordEjmmjj
# binding=LOCAL
# final_pc=0xbe568
# size=220
# instruction_count=55
# encoded_word_count=55
# body_sha256=b55f41f8bc8a2afc519eb15c23d4f8fefed134862a7d50c31643803d15c66d8d
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction

0x00000000000be568 (+0x00000000)  070e0000  MOV_XD_IMM                      X7, #0
0x00000000000be56c (+0x00000004)  0000038e  CMP.S64.EQ                      X0, X7
0x00000000000be570 (+0x00000008)  4020002d  JUMPC                           #45
0x00000000000be574 (+0x0000000c)  07100000  MOV_XD_IMM                      X8, #0
0x00000000000be578 (+0x00000010)  0000140e  CMP.S64.EQ                      X1, X8
0x00000000000be57c (+0x00000014)  4020002a  JUMPC                           #42
0x00000000000be580 (+0x00000018)  02922a00  ZEROEXT.U32                     X9, X2
0x00000000000be584 (+0x0000001c)  0000940e  CMP.S64.EQ                      X9, X8
0x00000000000be588 (+0x00000020)  40200027  JUMPC                           #39
0x00000000000be58c (+0x00000024)  1c840000  LD_XD_XN_IMM.B32                X2, X0, #0
0x00000000000be590 (+0x00000028)  004024ae  CMP.U64.LT                      X2, X9
0x00000000000be594 (+0x0000002c)  40200002  JUMPC                           #2
0x00000000000be598 (+0x00000030)  40000025  JUMP                            #37
0x00000000000be59c (+0x00000034)  020e2800  MOV_XD_XN.S64                   X7, X2
0x00000000000be5a0 (+0x00000038)  02ce0206  SHL.B64                         X7, #6
0x00000000000be5a4 (+0x0000003c)  00021381  ADD.S64                         X1, X1, X7
0x00000000000be5a8 (+0x00000040)  09c61201  STP_XI_XJ_XN.B64                X3, X4, X1, #0
0x00000000000be5ac (+0x00000044)  07060001  MOV_XD_IMM                      X3, #1
0x00000000000be5b0 (+0x00000048)  02063080  NEG.S64                         X3, X3
0x00000000000be5b4 (+0x0000004c)  03c61010  ST_XD_XN_IMM.B64                X3, X1, #16
0x00000000000be5b8 (+0x00000050)  0706000e  MOV_XD_IMM                      X3, #14
0x00000000000be5bc (+0x00000054)  03861018  ST_XD_XN_IMM.B32                X3, X1, #24
0x00000000000be5c0 (+0x00000058)  070e000d  MOV_XD_IMM                      X7, #13
0x00000000000be5c4 (+0x0000005c)  1c86001c  LD_XD_XN_IMM.B32                X3, X0, #28
0x00000000000be5c8 (+0x00000060)  0386101c  ST_XD_XN_IMM.B32                X3, X1, #28
0x00000000000be5cc (+0x00000064)  1c860018  LD_XD_XN_IMM.B32                X3, X0, #24
0x00000000000be5d0 (+0x00000068)  03861020  ST_XD_XN_IMM.B32                X3, X1, #32
0x00000000000be5d4 (+0x0000006c)  02866a00  ZEROEXT.U32                     X3, X6
0x00000000000be5d8 (+0x00000070)  1c880014  LD_XD_XN_IMM.B32                X4, X0, #20
0x00000000000be5dc (+0x00000074)  004033be  CMP.U64.GT                      X3, X7
0x00000000000be5e0 (+0x00000078)  03881024  ST_XD_XN_IMM.B32                X4, X1, #36
0x00000000000be5e4 (+0x0000007c)  07080090  MOV_XD_IMM                      X4, #144
0x00000000000be5e8 (+0x00000080)  40200008  JUMPC                           #8
0x00000000000be5ec (+0x00000084)  07080404  MOV_XD_IMM                      X4, #1028
0x00000000000be5f0 (+0x00000088)  07490000  MOVK                            X4, #0, #1
0x00000000000be5f4 (+0x0000008c)  07890000  MOVK                            X4, #0, #2
0x00000000000be5f8 (+0x00000090)  07c90000  MOVK                            X4, #0, #3
0x00000000000be5fc (+0x00000094)  020e0880  MOV_XD_SPR.S64                  X7, PC
0x00000000000be600 (+0x00000098)  00084381  ADD.S64                         X4, X4, X7
0x00000000000be604 (+0x0000009c)  01884180  LD_XD_XN.B32                    X4, X4, X3
0x00000000000be608 (+0x000000a0)  02ca0208  SHL.B64                         X5, #8
0x00000000000be60c (+0x000000a4)  00c6428b  OR.B64                          X3, X4, X5
0x00000000000be610 (+0x000000a8)  08021028  ADD_IMM.S64                     X1, X1, #40
0x00000000000be614 (+0x000000ac)  09861301  STP_XI_XJ_XN.B32                X3, X6, X1, #0
0x00000000000be618 (+0x000000b0)  08022001  ADD_IMM.S64                     X1, X2, #1
0x00000000000be61c (+0x000000b4)  070e0001  MOV_XD_IMM                      X7, #1
0x00000000000be620 (+0x000000b8)  03820000  ST_XD_XN_IMM.B32                X1, X0, #0
0x00000000000be624 (+0x000000bc)  02007800  MOV_XD_XN.S64                   X0, X7
0x00000000000be628 (+0x000000c0)  4061f000  RET
0x00000000000be62c (+0x000000c4)  1c820004  LD_XD_XN_IMM.B32                X1, X0, #4
0x00000000000be630 (+0x000000c8)  070e0000  MOV_XD_IMM                      X7, #0
0x00000000000be634 (+0x000000cc)  08021001  ADD_IMM.S64                     X1, X1, #1
0x00000000000be638 (+0x000000d0)  03820004  ST_XD_XN_IMM.B32                X1, X0, #4
0x00000000000be63c (+0x000000d4)  02007800  MOV_XD_XN.S64                   X0, X7
0x00000000000be640 (+0x000000d8)  4061f000  RET
