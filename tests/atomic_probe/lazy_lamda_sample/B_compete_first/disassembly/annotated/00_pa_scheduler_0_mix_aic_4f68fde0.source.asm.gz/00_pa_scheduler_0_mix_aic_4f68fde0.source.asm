# schema=pa_final_linked_disassembly/v1
# variant=compete-first
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=82a27e206ee1b2411964c0530c73adf92a2b032ac202a7c65c6b5f7d76a4571b
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=8fd6209b2f0f9d1fb48d4d8a16cf27649e26071153b908e1e0e39ca107d63589
# symbol=pa_scheduler_0_mix_aic
# binding=GLOBAL
# final_pc=0x0
# size=104
# instruction_count=26
# encoded_word_count=26
# body_sha256=3a8ecf84e154c1afc9dab2c992e3357d338c1d996a677931069f16310bdb28e5
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:26
#
# [DWARF] ccec/callback_runtime_entry.cpp:38
#      32 | #endif
#      33 | }
#      34 | 
#      35 | #if defined(PA_BUILD_AIC)
#      36 | PTO_SYNCALL_MIX_AIC_KERNEL_META(pa_scheduler_0_mix_aic, 1, 2);
#      37 | 
# >    38 | extern "C" __global__ __aicore__ void pa_scheduler_0_mix_aic(__gm__ pa_scheduler::SchedulerState *state) {
0x0000000000000000 (+0x00000000)  02004880  MOV_XD_SPR.S64                  X0, PARA_BASE
0x0000000000000004 (+0x00000004)  07c10000  MOVK                            X0, #0, #3
0x0000000000000008 (+0x00000008)  08c00000  DC_PRELOAD_XN_IMM.S64           [X0], #0
0x000000000000000c (+0x0000000c)  073af960  MOV_XD_IMM                      X29, #63840
0x0000000000000010 (+0x00000010)  077b000f  MOVK                            X29, #15, #1
0x0000000000000014 (+0x00000014)  029e3880  MOV_XD_SPR.F32                  X15, SYS_VA_BASE
0x0000000000000018 (+0x00000018)  02224880  MOV_XD_SPR.S64                  X17, PARA_BASE
0x000000000000001c (+0x0000001c)  003bd781  ADD.S64                         X29, X29, X15
0x0000000000000020 (+0x00000020)  021f0880  MOV_XD_SPR.S64                  X15, COREID
0x0000000000000024 (+0x00000024)  07207fff  MOV_XD_IMM                      X16, #32767
0x0000000000000028 (+0x00000028)  026202b4  SHR.U64                         X17, #52
0x000000000000002c (+0x0000002c)  00def80a  AND.B64                         X15, X15, X16
0x0000000000000030 (+0x00000030)  08231002  ADD_IMM.S64                     X17, X17, #2
0x0000000000000034 (+0x00000034)  02e2020e  SHL.B64                         X17, #14
0x0000000000000038 (+0x00000038)  081ef001  ADD_IMM.S64                     X15, X15, #1
0x000000000000003c (+0x0000003c)  003af884  MADD.S64                        X29, X15, X17
0x0000000000000040 (+0x00000040)  083dd788  ADD_IMM.S64                     X30, X29, #1928
0x0000000000000044 (+0x00000044)  02004880  MOV_XD_SPR.S64                  X0, PARA_BASE
0x0000000000000048 (+0x00000048)  07c10000  MOVK                            X0, #0, #3
0x000000000000004c (+0x0000004c)  1cc00000  LD_XD_XN_IMM.B64                X0, X0, #0
# [DWARF] ccec/callback_runtime_entry.cpp:39
# >    39 |     const uint32_t worker_id = static_cast<uint32_t>(get_block_idx());
0x0000000000000050 (+0x00000050)  02021880  MOV_XD_SPR.S64                  X1, BLOCKID
# [DWARF] ccec/callback_runtime_entry.cpp:40
# >    40 |     pa_scheduler_lazy_sample_callback_orchestration_aic(state, worker_id);
0x0000000000000054 (+0x00000054)  07040098  MOV_XD_IMM                      X2, #152
0x0000000000000058 (+0x00000058)  07450000  MOVK                            X2, #0, #1
0x000000000000005c (+0x0000005c)  07850000  MOVK                            X2, #0, #2
0x0000000000000060 (+0x00000060)  40422000  CALL                            X2, #0
# [DWARF] ccec/callback_runtime_entry.cpp:41
# >    41 | }
0x0000000000000064 (+0x00000064)  41600000  END
