# schema=pa_final_linked_disassembly/v1
# variant=original
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=76c961f846c7efc89b40942c3a8113530a6da2c7bfbdc601615852f8c5b79cfc
# final_text_address=0x0
# final_text_size=780344
# final_text_sha256=018ae7dc29ce78249b2e3bff84b0faa2e671e2448c9316719fb48bc59139d2fc
# symbol=_ZN3pto23TBinOps_2D_NoPostUpdateINS_5MulOpIfEEfLj64ELj8ELj128ELj128ELj128EEEvPU3AS6T0_S5_S5_jj.vector.thread
# binding=LOCAL
# final_pc=0xbe800
# size=48
# instruction_count=12
# encoded_word_count=12
# body_sha256=9afa7fa1b6031acff6f90ef3822167d31eeec4d90ee419db0b85dd7c40e5404c
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=rvec
# columns=final_pc function_relative_offset machine_word instruction

0x00000000000be800 (+0x00000000)  c410001d  RV_VAG                          A0, S4, S2, S0, S0
0x00000000000be804 (+0x00000004)  c201010d  RV_SMOVI                        S65, #128
0x00000000000be808 (+0x00000008)  c380219e  RV_VLOOPv2                      S7, #8, #2, #1
0x00000000000be80c (+0x0000000c)  c708004d  RV_SMOV.B32                     S67, S65
0x00000000000be810 (+0x00000010)  c300171e  RV_VLOOPv2.B32                  S6, #5, #1, #1
0x00000000000be814 (+0x00000014)  00200008  RV_VLD                          V0, [S8], A0, #NORAML
0x00000000000be818 (+0x00000018)  02280008  RV_VLD                          V1, [S10], A0, #NORAML
0x00000000000be81c (+0x0000001c)  a26c0150  RV_PLT.B32                      P1, S67
0x00000000000be820 (+0x00000020)  800027c0  RV_VMUL.F32                     V0, V0, V1, P1
0x00000000000be824 (+0x00000024)  40300108  RV_VST                          V0, [S12], A0, P1, #NORM_B32
0x00000000000be828 (+0x00000028)  c0000016  RV_SNOP.U16
0x00000000000be82c (+0x0000002c)  c0000017  RV_SEND.U16
