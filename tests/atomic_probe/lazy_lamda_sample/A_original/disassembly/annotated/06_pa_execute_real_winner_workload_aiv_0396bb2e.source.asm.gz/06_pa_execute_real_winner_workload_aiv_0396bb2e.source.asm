# schema=pa_final_linked_disassembly/v1
# variant=original
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=76c961f846c7efc89b40942c3a8113530a6da2c7bfbdc601615852f8c5b79cfc
# final_text_address=0x0
# final_text_size=780344
# final_text_sha256=018ae7dc29ce78249b2e3bff84b0faa2e671e2448c9316719fb48bc59139d2fc
# symbol=pa_execute_real_winner_workload_aiv
# binding=LOCAL
# final_pc=0x5ee18
# size=476
# instruction_count=119
# encoded_word_count=119
# body_sha256=158c11e2f546c21643c2addb244ffefe3e46e5aeee5b04fbd4873dcd33a07363
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:119
#
# [DWARF] ccec/ccec_ops.h:360
#     354 |     pa_scheduler::TaskKind kind
#     355 | ) {
#     356 | #elif defined(PA_BUILD_AIV)
#     357 | extern "C" __attribute__((noinline, used)) __aicore__ void pa_execute_real_winner_workload_aiv(
#     358 |     __gm__ pa_scheduler::SchedulerState *state, __gm__ pa_scheduler::WorkerState *worker,
#     359 |     pa_scheduler::TaskKind kind
# >   360 | ) {
0x000000000005ee18 (+0x00000000)  072207a0  MOV_XD_IMM                      X17, #1952
0x000000000005ee1c (+0x00000004)  03ffe868  ST_XD_XN_IMM.B64                X31, X30, #2152
0x000000000005ee20 (+0x00000008)  03fbe860  ST_XD_XN_IMM.B64                X29, X30, #2144
0x000000000005ee24 (+0x0000000c)  003be882  SUB.S64                         X29, X30, X17
0x000000000005ee28 (+0x00000010)  07220018  MOV_XD_IMM                      X17, #24
0x000000000005ee2c (+0x00000014)  003de882  SUB.S64                         X30, X30, X17
0x000000000005ee30 (+0x00000018)  02080800  MOV_XD_XN.S64                   X4, X0
0x000000000005ee34 (+0x0000001c)  0700f758  MOV_XD_IMM                      X0, #63320
0x000000000005ee38 (+0x00000020)  07413c05  MOVK                            X0, #15365, #1
# [DWARF] ccec/ccec_ops.h:362
#     361 | #endif
# >   362 |     const uint64_t workspace = state->winner_workload.workspace_base;
0x000000000005ee3c (+0x00000024)  00004001  ADD.S64                         X0, X4, X0
0x000000000005ee40 (+0x00000028)  1cc00000  LD_XD_XN_IMM.B64                X0, X0, #0
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005ee44 (+0x0000002c)  02862980  SIGNEXT.S32                     X3, X2
0x000000000005ee48 (+0x00000030)  070a0003  MOV_XD_IMM                      X5, #3
0x000000000005ee4c (+0x00000034)  000032ae  CMP.S64.LT                      X3, X5
0x000000000005ee50 (+0x00000038)  40200002  JUMPC                           #2
0x000000000005ee54 (+0x0000003c)  4000000a  JUMP                            #10
0x000000000005ee58 (+0x00000040)  070a0001  MOV_XD_IMM                      X5, #1
0x000000000005ee5c (+0x00000044)  000032be  CMP.S64.GT                      X3, X5
0x000000000005ee60 (+0x00000048)  4020000d  JUMPC                           #13
0x000000000005ee64 (+0x0000004c)  02862a00  ZEROEXT.U32                     X3, X2
0x000000000005ee68 (+0x00000050)  0000329e  CMP.S64.NE                      X3, X5
0x000000000005ee6c (+0x00000054)  07060000  MOV_XD_IMM                      X3, #0
0x000000000005ee70 (+0x00000058)  40200014  JUMPC                           #20
0x000000000005ee74 (+0x0000005c)  0706f748  MOV_XD_IMM                      X3, #63304
0x000000000005ee78 (+0x00000060)  4000000f  JUMP                            #15
0x000000000005ee7c (+0x00000064)  070a0004  MOV_XD_IMM                      X5, #4
0x000000000005ee80 (+0x00000068)  000032ae  CMP.S64.LT                      X3, X5
0x000000000005ee84 (+0x0000006c)  40200002  JUMPC                           #2
0x000000000005ee88 (+0x00000070)  40000005  JUMP                            #5
0x000000000005ee8c (+0x00000074)  0706f750  MOV_XD_IMM                      X3, #63312
0x000000000005ee90 (+0x00000078)  40000009  JUMP                            #9
0x000000000005ee94 (+0x0000007c)  0706f74c  MOV_XD_IMM                      X3, #63308
0x000000000005ee98 (+0x00000080)  40000007  JUMP                            #7
0x000000000005ee9c (+0x00000084)  02862a00  ZEROEXT.U32                     X3, X2
0x000000000005eea0 (+0x00000088)  0000328e  CMP.S64.EQ                      X3, X5
0x000000000005eea4 (+0x0000008c)  07060000  MOV_XD_IMM                      X3, #0
0x000000000005eea8 (+0x00000090)  40200002  JUMPC                           #2
0x000000000005eeac (+0x00000094)  40000005  JUMP                            #5
0x000000000005eeb0 (+0x00000098)  0706f754  MOV_XD_IMM                      X3, #63316
0x000000000005eeb4 (+0x0000009c)  07473c05  MOVK                            X3, #15365, #1
0x000000000005eeb8 (+0x000000a0)  00064181  ADD.S64                         X3, X4, X3
0x000000000005eebc (+0x000000a4)  1c863000  LD_XD_XN_IMM.B32                X3, X3, #0
0x000000000005eec0 (+0x000000a8)  070af744  MOV_XD_IMM                      X5, #63300
0x000000000005eec4 (+0x000000ac)  074b3c05  MOVK                            X5, #15365, #1
# [DWARF] ccec/ccec_ops.h:369
#     363 |     const uint32_t repeats = pa_scheduler::WorkloadCountForKind(
#     364 |         state->winner_workload.repeats, kind
#     365 |     );
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
# >   369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
0x000000000005eec8 (+0x000000b0)  000a4281  ADD.S64                         X5, X4, X5
0x000000000005eecc (+0x000000b4)  1c8a5000  LD_XD_XN_IMM.B32                X5, X5, #0
0x000000000005eed0 (+0x000000b8)  070c0001  MOV_XD_IMM                      X6, #1
0x000000000005eed4 (+0x000000bc)  0000531e  CMP.S64.NE                      X5, X6
0x000000000005eed8 (+0x000000c0)  40200042  JUMPC                           #66
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005eedc (+0x000000c4)  070a0000  MOV_XD_IMM                      X5, #0
# [DWARF] ccec/ccec_ops.h:369
#     363 |     const uint32_t repeats = pa_scheduler::WorkloadCountForKind(
#     364 |         state->winner_workload.repeats, kind
#     365 |     );
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
# >   369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
0x000000000005eee0 (+0x000000c8)  0000028e  CMP.S64.EQ                      X0, X5
0x000000000005eee4 (+0x000000cc)  4020003f  JUMPC                           #63
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005eee8 (+0x000000d0)  070af760  MOV_XD_IMM                      X5, #63328
0x000000000005eeec (+0x000000d4)  074b3c05  MOVK                            X5, #15365, #1
# [DWARF] ccec/ccec_ops.h:371
#     365 |     );
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
#     369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
#     370 |         workspace == 0 ||
# >   371 |         state->winner_workload.workspace_bytes < pa_scheduler::winner_workload::kWorkspaceBytes ||
0x000000000005eef0 (+0x000000d8)  00084281  ADD.S64                         X4, X4, X5
0x000000000005eef4 (+0x000000dc)  1cc84000  LD_XD_XN_IMM.B64                X4, X4, #0
0x000000000005eef8 (+0x000000e0)  070a0000  MOV_XD_IMM                      X5, #0
0x000000000005eefc (+0x000000e4)  074b00c2  MOVK                            X5, #194, #1
0x000000000005ef00 (+0x000000e8)  004042ae  CMP.U64.LT                      X4, X5
0x000000000005ef04 (+0x000000ec)  40200037  JUMPC                           #55
# [DWARF] ccec/ccec_ops.h:372
# >   372 |         worker->core_idx < 0 || static_cast<uint32_t>(worker->core_idx) >= pa_scheduler::kWorkers ||
0x000000000005ef08 (+0x000000f0)  1c881004  LD_XD_XN_IMM.B32                X4, X1, #4
0x000000000005ef0c (+0x000000f4)  070a0000  MOV_XD_IMM                      X5, #0
0x000000000005ef10 (+0x000000f8)  02824980  SIGNEXT.S32                     X1, X4
0x000000000005ef14 (+0x000000fc)  000012ae  CMP.S64.LT                      X1, X5
0x000000000005ef18 (+0x00000100)  40200032  JUMPC                           #50
0x000000000005ef1c (+0x00000104)  08823081  SUB_IMM.S64                     X1, X3, #129
0x000000000005ef20 (+0x00000108)  070aff80  MOV_XD_IMM                      X5, #65408
0x000000000005ef24 (+0x0000010c)  02821a00  ZEROEXT.U32                     X1, X1
0x000000000005ef28 (+0x00000110)  074bffff  MOVK                            X5, #65535, #1
0x000000000005ef2c (+0x00000114)  004012ae  CMP.U64.LT                      X1, X5
0x000000000005ef30 (+0x00000118)  4020002c  JUMPC                           #44
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005ef34 (+0x0000011c)  02824a00  ZEROEXT.U32                     X1, X4
0x000000000005ef38 (+0x00000120)  070a005f  MOV_XD_IMM                      X5, #95
# [DWARF] ccec/ccec_ops.h:372
#     366 |     // 错版 host、截断 workspace 或越界 worker 不能继续解引用 GM。这里不额外
#     367 |     // 写共享 fatal，避免在正常热路增加 atomic；host 的逐 kind sentinel/数值
#     368 |     // 闭环会把这种配置错误判为失败。
#     369 |     if (state->winner_workload.version != pa_scheduler::kWinnerWorkloadConfigVersion ||
#     370 |         workspace == 0 ||
#     371 |         state->winner_workload.workspace_bytes < pa_scheduler::winner_workload::kWorkspaceBytes ||
# >   372 |         worker->core_idx < 0 || static_cast<uint32_t>(worker->core_idx) >= pa_scheduler::kWorkers ||
0x000000000005ef3c (+0x00000124)  004012be  CMP.U64.GT                      X1, X5
0x000000000005ef40 (+0x00000128)  40200028  JUMPC                           #40
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005ef44 (+0x0000012c)  028a2980  SIGNEXT.S32                     X5, X2
0x000000000005ef48 (+0x00000130)  07020004  MOV_XD_IMM                      X1, #4
0x000000000005ef4c (+0x00000134)  000050ae  CMP.S64.LT                      X5, X1
0x000000000005ef50 (+0x00000138)  40200002  JUMPC                           #2
0x000000000005ef54 (+0x0000013c)  40000006  JUMP                            #6
0x000000000005ef58 (+0x00000140)  02822a00  ZEROEXT.U32                     X1, X2
0x000000000005ef5c (+0x00000144)  070a0002  MOV_XD_IMM                      X5, #2
0x000000000005ef60 (+0x00000148)  0000129e  CMP.S64.NE                      X1, X5
0x000000000005ef64 (+0x0000014c)  4020001f  JUMPC                           #31
0x000000000005ef68 (+0x00000150)  40000005  JUMP                            #5
0x000000000005ef6c (+0x00000154)  028a2a00  ZEROEXT.U32                     X5, X2
0x000000000005ef70 (+0x00000158)  0000508e  CMP.S64.EQ                      X5, X1
0x000000000005ef74 (+0x0000015c)  40200002  JUMPC                           #2
0x000000000005ef78 (+0x00000160)  4000001a  JUMP                            #26
# [DWARF] ccec/ccec_ops.h:386
#     380 | #endif
#     381 |     __gm__ float *input_a = reinterpret_cast<__gm__ float *>(workspace);
#     382 |     __gm__ float *input_b = reinterpret_cast<__gm__ float *>(
#     383 |         workspace + pa_scheduler::winner_workload::kTileBytes
#     384 |     );
#     385 |     const uint32_t kind_slot =
# >   386 |         (kind == pa_scheduler::TaskKind::Pv || kind == pa_scheduler::TaskKind::Up) ? 1U : 0U;
0x000000000005ef7c (+0x00000164)  028a2a00  ZEROEXT.U32                     X5, X2
0x000000000005ef80 (+0x00000168)  08842003  SUB_IMM.S64                     X2, X2, #3
0x000000000005ef84 (+0x0000016c)  02842a00  ZEROEXT.U32                     X2, X2
0x000000000005ef88 (+0x00000170)  070c0002  MOV_XD_IMM                      X6, #2
0x000000000005ef8c (+0x00000174)  0044232f  CMPN.U64.LT                     X2, X2, X6
# [DWARF] ccec/ccec_ops.h:389
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
# >   389 |         static_cast<uint32_t>(worker->core_idx) *
0x000000000005ef90 (+0x00000178)  02c80201  SHL.B64                         X4, #1
# [DWARF] ccec/ccec_ops.h:388
#     382 |     __gm__ float *input_b = reinterpret_cast<__gm__ float *>(
#     383 |         workspace + pa_scheduler::winner_workload::kTileBytes
#     384 |     );
#     385 |     const uint32_t kind_slot =
#     386 |         (kind == pa_scheduler::TaskKind::Pv || kind == pa_scheduler::TaskKind::Up) ? 1U : 0U;
#     387 |     const uint32_t output_tile =
# >   388 |         pa_scheduler::winner_workload::kSharedInputTiles +
0x000000000005ef94 (+0x0000017c)  00c4410b  OR.B64                          X2, X4, X2
# [DWARF] ccec/ccec_ops.h:390
#     389 |         static_cast<uint32_t>(worker->core_idx) *
# >   390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
0x000000000005ef98 (+0x00000180)  08042002  ADD_IMM.S64                     X2, X2, #2
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005ef9c (+0x00000184)  07020000  MOV_XD_IMM                      X1, #0
# [DWARF] ccec/ccec_ops.h:393
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
#     389 |         static_cast<uint32_t>(worker->core_idx) *
#     390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
#     391 |         kind_slot;
#     392 |     __gm__ float *output = reinterpret_cast<__gm__ float *>(
# >   393 |         workspace + static_cast<uint64_t>(output_tile) *
0x000000000005efa0 (+0x00000188)  02842a00  ZEROEXT.U32                     X2, X2
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005efa4 (+0x0000018c)  07430001  MOVK                            X1, #1, #1
# [DWARF] ccec/ccec_ops.h:393
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
#     389 |         static_cast<uint32_t>(worker->core_idx) *
#     390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
#     391 |         kind_slot;
#     392 |     __gm__ float *output = reinterpret_cast<__gm__ float *>(
# >   393 |         workspace + static_cast<uint64_t>(output_tile) *
0x000000000005efa8 (+0x00000190)  02c40210  SHL.B64                         X2, #16
# [DWARF] ccec/ccec_ops.h:383
#     377 |     if (kind != pa_scheduler::TaskKind::Qk && kind != pa_scheduler::TaskKind::Pv) return;
#     378 | #elif defined(PA_BUILD_AIV)
#     379 |     if (kind != pa_scheduler::TaskKind::Sf && kind != pa_scheduler::TaskKind::Up) return;
#     380 | #endif
#     381 |     __gm__ float *input_a = reinterpret_cast<__gm__ float *>(workspace);
#     382 |     __gm__ float *input_b = reinterpret_cast<__gm__ float *>(
# >   383 |         workspace + pa_scheduler::winner_workload::kTileBytes
0x000000000005efac (+0x00000194)  00020081  ADD.S64                         X1, X0, X1
# [DWARF] ccec/ccec_ops.h:399
#     393 |         workspace + static_cast<uint64_t>(output_tile) *
#     394 |             pa_scheduler::winner_workload::kTileBytes
#     395 |     );
#     396 | #if defined(PA_BUILD_AIC)
#     397 |     pa_scheduler_ccec::pa_real_cube_workload_aic(input_a, input_b, output, repeats);
#     398 | #elif defined(PA_BUILD_AIV)
# >   399 |     if (kind == pa_scheduler::TaskKind::Sf) {
0x000000000005efb0 (+0x00000198)  0000531e  CMP.S64.NE                      X5, X6
# [DWARF] ccec/ccec_ops.h:393
#     387 |     const uint32_t output_tile =
#     388 |         pa_scheduler::winner_workload::kSharedInputTiles +
#     389 |         static_cast<uint32_t>(worker->core_idx) *
#     390 |             pa_scheduler::winner_workload::kOutputTilesPerWorker +
#     391 |         kind_slot;
#     392 |     __gm__ float *output = reinterpret_cast<__gm__ float *>(
# >   393 |         workspace + static_cast<uint64_t>(output_tile) *
0x000000000005efb4 (+0x0000019c)  00042001  ADD.S64                         X2, X2, X0
# [DWARF] ccec/ccec_ops.h:399
#     394 |             pa_scheduler::winner_workload::kTileBytes
#     395 |     );
#     396 | #if defined(PA_BUILD_AIC)
#     397 |     pa_scheduler_ccec::pa_real_cube_workload_aic(input_a, input_b, output, repeats);
#     398 | #elif defined(PA_BUILD_AIV)
# >   399 |     if (kind == pa_scheduler::TaskKind::Sf) {
0x000000000005efb8 (+0x000001a0)  40200006  JUMPC                           #6
# [DWARF] ccec/ccec_ops.h:400
# >   400 |         pa_scheduler_ccec::pa_real_vector_add_workload_aiv(input_a, input_b, output, repeats);
0x000000000005efbc (+0x000001a4)  0708ff0e  MOV_XD_IMM                      X4, #65294
0x000000000005efc0 (+0x000001a8)  0749ffff  MOVK                            X4, #65535, #1
0x000000000005efc4 (+0x000001ac)  0789ffff  MOVK                            X4, #65535, #2
0x000000000005efc8 (+0x000001b0)  40424000  CALL                            X4, #0
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005efcc (+0x000001b4)  40000005  JUMP                            #5
# [DWARF] ccec/ccec_ops.h:402
#     396 | #if defined(PA_BUILD_AIC)
#     397 |     pa_scheduler_ccec::pa_real_cube_workload_aic(input_a, input_b, output, repeats);
#     398 | #elif defined(PA_BUILD_AIV)
#     399 |     if (kind == pa_scheduler::TaskKind::Sf) {
#     400 |         pa_scheduler_ccec::pa_real_vector_add_workload_aiv(input_a, input_b, output, repeats);
#     401 |     } else {
# >   402 |         pa_scheduler_ccec::pa_real_vector_mul_workload_aiv(input_a, input_b, output, repeats);
0x000000000005efd0 (+0x000001b8)  0708ff4c  MOV_XD_IMM                      X4, #65356
0x000000000005efd4 (+0x000001bc)  0749ffff  MOVK                            X4, #65535, #1
0x000000000005efd8 (+0x000001c0)  0789ffff  MOVK                            X4, #65535, #2
0x000000000005efdc (+0x000001c4)  40424000  CALL                            X4, #0
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x000000000005efe0 (+0x000001c8)  07220018  MOV_XD_IMM                      X17, #24
0x000000000005efe4 (+0x000001cc)  003de881  ADD.S64                         X30, X30, X17
# [DWARF] ccec/ccec_ops.h:405
#     399 |     if (kind == pa_scheduler::TaskKind::Sf) {
#     400 |         pa_scheduler_ccec::pa_real_vector_add_workload_aiv(input_a, input_b, output, repeats);
#     401 |     } else {
#     402 |         pa_scheduler_ccec::pa_real_vector_mul_workload_aiv(input_a, input_b, output, repeats);
#     403 |     }
#     404 | #endif
# >   405 | }
0x000000000005efe8 (+0x000001d0)  1cffe868  LD_XD_XN_IMM.B64                X31, X30, #2152
0x000000000005efec (+0x000001d4)  1cfbe860  LD_XD_XN_IMM.B64                X29, X30, #2144
0x000000000005eff0 (+0x000001d8)  4061f000  RET
