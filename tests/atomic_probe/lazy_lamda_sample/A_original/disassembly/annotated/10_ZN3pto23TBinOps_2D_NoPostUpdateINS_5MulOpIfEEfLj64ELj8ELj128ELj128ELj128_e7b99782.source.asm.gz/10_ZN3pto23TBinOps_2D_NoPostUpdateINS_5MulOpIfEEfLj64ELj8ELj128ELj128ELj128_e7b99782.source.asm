# schema=pa_final_linked_disassembly/v1
# variant=original
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=76c961f846c7efc89b40942c3a8113530a6da2c7bfbdc601615852f8c5b79cfc
# final_text_address=0x0
# final_text_size=780344
# final_text_sha256=018ae7dc29ce78249b2e3bff84b0faa2e671e2448c9316719fb48bc59139d2fc
# symbol=_ZN3pto23TBinOps_2D_NoPostUpdateINS_5MulOpIfEEfLj64ELj8ELj128ELj128ELj128EEEvPU3AS6T0_S5_S5_jj.vector.thread
# binding=LOCAL
# final_pc=0xbe800
# size=48
# instruction_count=12
# encoded_word_count=12
# body_sha256=9afa7fa1b6031acff6f90ef3822167d31eeec4d90ee419db0b85dd7c40e5404c
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=rvec
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:12
#
# [DWARF] ccec/ccec_ops.h:0
# [SOURCE unavailable]
0x00000000000be800 (+0x00000000)  c410001d  RV_VAG                          A0, S4, S2, S0, S0
0x00000000000be804 (+0x00000004)  c201010d  RV_SMOVI                        S65, #128
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TBinOp.hpp:79
#      73 |     __VEC_SCOPE__
#      74 |     {
#      75 |         RegTensor<T> vreg0, vreg1, vreg2;
#      76 |         MaskReg preg;
#      77 |         constexpr auto distValue =
#      78 |             std::integral_constant<::DistVST, static_cast<::DistVST>(GetDistVst<T, DistVST::DIST_NORM>())>();
# >    79 |         for (uint16_t i = 0; i < (uint16_t)(validRows); ++i) {
0x00000000000be808 (+0x00000008)  c380219e  RV_VLOOPv2                      S7, #8, #2, #1
0x00000000000be80c (+0x0000000c)  c708004d  RV_SMOV.B32                     S67, S65
# [DWARF] $ASCEND_HOME_PATH/x86_64-linux/include/pto/npu/a5/TBinOp.hpp:81
#      80 |             uint32_t sreg = (uint32_t)(validCols);
# >    81 |             for (uint16_t j = 0; j < (uint16_t)repeatTimes; ++j) {
0x00000000000be810 (+0x00000010)  c300171e  RV_VLOOPv2.B32                  S6, #5, #1, #1
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:1614
#    1608 |     defined(__DAV_310R6__) || defined(__DAV_L510__) ||                         \
#    1609 |     (__NPU_ARCH__ == 5102) || (__NPU_ARCH__ == 9201) ||                        \
#    1610 |     (__NPU_ARCH__ == 9202) || (__NPU_ARCH__ == 3510) || (__NPU_ARCH__ == 5161)
#    1611 | __VF_VLDS(bfloat16_t, bf16, v128)
#    1612 | #endif
#    1613 | __VF_VLDS(half, f16, v128)
# >  1614 | __VF_VLDS(float, f32, v64)
0x00000000000be814 (+0x00000014)  00200008  RV_VLD                          V0, [S8], A0, #NORAML
0x00000000000be818 (+0x00000018)  02280008  RV_VLD                          V1, [S10], A0, #NORAML
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:6712
#    6706 |     scalar = ret.scalar_out;                                                   \
#    6707 |     return ret.mask;                                                           \
#    6708 |   }
#    6709 | 
#    6710 | __VF_PLT_V300(b8, uint32_t)
#    6711 | __VF_PLT_V300(b16, uint32_t)
# >  6712 | __VF_PLT_V300(b32, uint32_t)
0x00000000000be81c (+0x0000001c)  a26c0150  RV_PLT.B32                      P1, S67
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:7424
#    7418 |     (__NPU_ARCH__ == 5102) && (__NPU_ARCH__ != 5161)
#    7419 | __VF_BINARY_OP(vmul, s8, s8, v256)
#    7420 | __VF_BINARY_OP(vmul, u8, u8, v256)
#    7421 | #endif
#    7422 | 
#    7423 | #if __NPU_ARCH__ != 9202
# >  7424 | __VF_BINARY_OP(vmul, f32, f32, v64)
0x00000000000be820 (+0x00000020)  800027c0  RV_VMUL.F32                     V0, V0, V1, P1
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:2097
#    2091 | __VF_VSTS(vsts, uint8_t, u8, v256, NOT_DEPRECATED)
#    2092 | __VF_VSTS(vsts, int16_t, s16, v128, NOT_DEPRECATED)
#    2093 | __VF_VSTS(vsts, uint16_t, u16, v128, NOT_DEPRECATED)
#    2094 | __VF_VSTS(vsts, int32_t, s32, v64, NOT_DEPRECATED)
#    2095 | __VF_VSTS(vsts, uint32_t, u32, v64, NOT_DEPRECATED)
#    2096 | __VF_VSTS(vsts, half, f16, v128, NOT_DEPRECATED)
# >  2097 | __VF_VSTS(vsts, float, f32, v64, NOT_DEPRECATED)
0x00000000000be824 (+0x00000024)  40300108  RV_VST                          V0, [S12], A0, P1, #NORM_B32
0x00000000000be828 (+0x00000028)  c0000016  RV_SNOP.U16
# [DWARF] $ASCEND_HOME_PATH/tools/bisheng_compiler/lib/clang/15.0.5/include/__clang_cce_vector_intrinsics.h:0
# [SOURCE unavailable]
0x00000000000be82c (+0x0000002c)  c0000017  RV_SEND.U16
