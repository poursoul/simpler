# schema=pa_final_linked_disassembly/v1
# variant=compete-first-lazy
# final_elf=pa_scheduler_kernel.o
# final_elf_sha256=8d293c52312429d13efe89592ed705c672ceef1f2875b5e3bd25582419d37893
# final_text_address=0x0
# final_text_size=547640
# final_text_sha256=866ed1081ebb94038a8feca87ccedf95e67aebfdaef11651c109f86672be2bdd
# symbol=pa_scheduler_0_mix_aiv
# binding=GLOBAL
# final_pc=0x42ab0
# size=124
# instruction_count=31
# encoded_word_count=31
# body_sha256=63f9349fa440318678bcf3e98ad719502bd907f7537fb0f083eac32895e3ad9b
# decoder=$ASCEND_HOME_PATH/x86_64-linux/simulator/dav_3510/lib/libpem_davinci.so
# decoder_sha256=29835d2439d6dd464d34a212ad4bbd5c29af6a38465da09a6c273401d9a96dcb
# decoder_mode=scalar
# columns=final_pc function_relative_offset machine_word instruction
# annotation_schema=pa_source_annotated_disassembly/v1
# annotation_rule=DWARF supplies only file:line; SOURCE rows are copied from local source files
# annotation_warning=comments have source context only and do not own an exact machine address
# annotation_instruction_slice=0:31
#
# [DWARF] ccec/callback_runtime_entry.cpp:45
#      39 |     const uint32_t worker_id = static_cast<uint32_t>(get_block_idx());
#      40 |     pa_scheduler_lazy_sample_callback_orchestration_aic(state, worker_id);
#      41 | }
#      42 | #elif defined(PA_BUILD_AIV)
#      43 | PTO_SYNCALL_MIX_AIC_KERNEL_META(pa_scheduler_0_mix_aiv, 1, 2);
#      44 | 
# >    45 | extern "C" __global__ __aicore__ void pa_scheduler_0_mix_aiv(__gm__ pa_scheduler::SchedulerState *state) {
0x0000000000042ab0 (+0x00000000)  02004880  MOV_XD_SPR.S64                  X0, PARA_BASE
0x0000000000042ab4 (+0x00000004)  07c10000  MOVK                            X0, #0, #3
0x0000000000042ab8 (+0x00000008)  08c00000  DC_PRELOAD_XN_IMM.S64           [X0], #0
0x0000000000042abc (+0x0000000c)  073af960  MOV_XD_IMM                      X29, #63840
0x0000000000042ac0 (+0x00000010)  077b000f  MOVK                            X29, #15, #1
0x0000000000042ac4 (+0x00000014)  029e3880  MOV_XD_SPR.F32                  X15, SYS_VA_BASE
0x0000000000042ac8 (+0x00000018)  02224880  MOV_XD_SPR.S64                  X17, PARA_BASE
0x0000000000042acc (+0x0000001c)  003bd781  ADD.S64                         X29, X29, X15
0x0000000000042ad0 (+0x00000020)  021f0880  MOV_XD_SPR.S64                  X15, COREID
0x0000000000042ad4 (+0x00000024)  07207fff  MOV_XD_IMM                      X16, #32767
0x0000000000042ad8 (+0x00000028)  026202b4  SHR.U64                         X17, #52
0x0000000000042adc (+0x0000002c)  00def80a  AND.B64                         X15, X15, X16
0x0000000000042ae0 (+0x00000030)  08231002  ADD_IMM.S64                     X17, X17, #2
0x0000000000042ae4 (+0x00000034)  02e2020e  SHL.B64                         X17, #14
0x0000000000042ae8 (+0x00000038)  081ef001  ADD_IMM.S64                     X15, X15, #1
0x0000000000042aec (+0x0000003c)  003af884  MADD.S64                        X29, X15, X17
0x0000000000042af0 (+0x00000040)  083dd788  ADD_IMM.S64                     X30, X29, #1928
0x0000000000042af4 (+0x00000044)  02004880  MOV_XD_SPR.S64                  X0, PARA_BASE
0x0000000000042af8 (+0x00000048)  07c10000  MOVK                            X0, #0, #3
0x0000000000042afc (+0x0000004c)  1cc00000  LD_XD_XN_IMM.B64                X0, X0, #0
# [DWARF] ccec/callback_runtime_entry.cpp:46
# >    46 |     const uint32_t vector_id = static_cast<uint32_t>(get_block_idx() * get_subblockdim() + get_subblockid());
0x0000000000042b00 (+0x00000050)  0283f880  MOV_XD_SPR.F32                  X1, SUBBLOCKDIM
0x0000000000042b04 (+0x00000054)  02c40880  MOV_XD_SPR.B64                  X2, SUBBLOCKID
0x0000000000042b08 (+0x00000058)  02061880  MOV_XD_SPR.S64                  X3, BLOCKID
0x0000000000042b0c (+0x0000005c)  00021183  MUL.S64                         X1, X1, X3
0x0000000000042b10 (+0x00000060)  00021101  ADD.S64                         X1, X1, X2
# [DWARF] ccec/callback_runtime_entry.cpp:47
# >    47 |     const uint32_t worker_id = pa_scheduler::kAicWorkers + vector_id;
0x0000000000042b14 (+0x00000064)  08021020  ADD_IMM.S64                     X1, X1, #32
# [DWARF] ccec/callback_runtime_entry.cpp:48
# >    48 |     pa_scheduler_lazy_sample_callback_orchestration_aiv(state, worker_id);
0x0000000000042b18 (+0x00000068)  07046d34  MOV_XD_IMM                      X2, #27956
0x0000000000042b1c (+0x0000006c)  07450000  MOVK                            X2, #0, #1
0x0000000000042b20 (+0x00000070)  07850000  MOVK                            X2, #0, #2
0x0000000000042b24 (+0x00000074)  40422000  CALL                            X2, #0
# [DWARF] ccec/callback_runtime_entry.cpp:49
# >    49 | }
0x0000000000042b28 (+0x00000078)  41600000  END
